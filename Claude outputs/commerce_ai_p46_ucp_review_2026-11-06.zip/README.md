# commerce_ai p46 — UCP 스키마 준비·캐시 남은 시간 보완 (2026-11-06)

GPT 검토(11-06 17:11, p45 대상) 반영분입니다. UCP 패키지는 여전히 어떤 앱 경로에도 연결하지 않았습니다(AST 테스트로 고정).

## 반영 항목

| GPT 지적 | p46 변경 | 확인 테스트 |
|---|---|---|
| 스키마 다운로드와 검증 준비가 분리됨, 중첩 `$id` 미반영 | `schemas.prepare()`가 판매자 POST 전에 실행: 문서 수집(중첩 `$id`를 기준 주소로) → `Registry(retrieve=조회 금지).with_resources().crawl()` → 각 문서 `check_schema` + 모든 `$ref` lookup → `#/$defs/search_response` 확인 → `Draft202012Validator` 생성 → `Prepared` 반환. `$dynamicRef`·`$recursiveRef`·`$dynamicAnchor`·`$recursiveAnchor`는 요청 전에 보류. 응답 검증은 준비된 검증기만 사용(검증 중 네트워크 조회 없음) | `test_nested_id_is_the_base_for_relative_refs`(GPT 재현 `sub/base.json → sub/leaf.json`), `test_embedded_id_inside_a_document_changes_the_base`, `test_unresolvable_or_unsupported_schema_means_zero_posts`(REST·MCP × 5사례, POST 0회) |
| 스키마 GET 타임아웃이 결과 객체로 안 돌아옴 | `schemas.fetch()`가 GET 예외(타임아웃·연결 실패)를 `SchemaError`로 감쌈. `client.search()`는 준비 단계의 모든 예외를 `schema_unavailable`로 반환 | `test_schema_fetch_timeout_returns_schema_unavailable`(REST·MCP × TimeoutError·ConnectionError, POST 0회) |
| 프로필 캐시가 `Age`·`Date`를 반영하지 않음 | `discovery.cache_seconds(headers, now)` = `max-age − max(Age, now−Date)`, 0 미만은 0, 상한 86400. 헤더 없음·`public`만·`no-store`·`no-cache`·`private`는 0(저장 안 함) | `test_cache_uses_only_the_remaining_freshness`(`max-age=10, Age: 9` → 1초 등 6사례) |
| (공통 검색 연결 대비) 카드 key가 상품명에 따라 달라짐 | `explain.card_key()`: UCP 카드는 `host·product_id·variant_id`로 key 생성 → 상품명이 바뀌어도 동일, 변환 key == enrich 뒤 key, 가격 비교 차단 표시 유지 | `test_ucp_card_key_is_stable_across_title_changes_and_enrich` |

`max_docs=80`은 유지했습니다(공식 스키마 fixture 49개).

## 검증 결과

- `ucp_tests_p46.txt`: UCP 122 passed (p45 99 → +23)
- `subset_tests_p46.txt`: ucp·chat·mcp_adapter·public_guard 668 passed, 1 failed, 2 skipped
  - 실패 1개 `test_the_trace_reaches_the_api_only_in_dev_mode`는 기존 항목. `.env`의 `CHAT_DEV_TRACE=0`(운영자 결정으로 유지) 때문이며 p46과 무관
- `full_tests_after.txt`: 전체 5,434 passed, 7 failed, 5 skipped. 실패 7개는 p39부터 같은 목록(persistence i5b characterization 등)
- `mutation_check_p46.txt`: p45 코드(`before/`)에 p46 테스트를 돌린 결과 22 failed, 100 passed → 새 테스트가 이번 수정 없이는 실패함을 확인
  - `test_fixture_search_response_conforms_to_official_schema`의 실패는 p46에서 바뀐 `prepare()` 반환형(Prepared)을 쓰기 때문이며 기능 회귀가 아님
- `live_search_p46.txt`: 실제 판매자 검색
  - 우리 프로필 `https://trendguide.kr/.well-known/ucp` 게시 점검 통과(https·리다이렉트 없음·`public, max-age=3600`·JSON)
  - allbirds.com: 협상 성공(2026-08-25, MCP), **판매자가 프로필을 받아 검색 성공**, 요청 전 준비한 검증기로 응답 스키마 검증 통과
  - 상품 5개 모두 USD → 원화 카드 0개(설계대로: 원화 가격만 카드화)

## 반영 전 안전 확인

p45 때 최신 맥 파일을 오래된 사본으로 덮어쓴 사고가 있어, 이번에는 맥 파일 mtime이 p45 반영 직후 그대로인지 확인하고, `p46.diff`의 삭제 줄이 모두 의도한 교체인지 검토한 뒤 복사했습니다. `SHA256_before.txt`·`SHA256_after.txt` 첨부.

## 파일 구성

- `p46.diff` — 변경 전체(discovery.py, client.py, schemas.py, chat/explain.py, test_ucp_catalog.py)
- `before/` — 변경 전 원본, `repo/` — 변경 후 UCP 관련 코드·테스트·fixture·점검 스크립트
- `README.txt` — 백업 폴더 원본 메모

## 다음 순서(GPT 제안)

스키마·캐시 보완(완료) → 판매자 실제 검색 성공 확인(완료) → **공통 검색 연결 검토**(미착수). 원화로 판매하는 국내 UCP 판매자가 아직 없어 연결해도 카드가 나오지 않는 상태입니다.
