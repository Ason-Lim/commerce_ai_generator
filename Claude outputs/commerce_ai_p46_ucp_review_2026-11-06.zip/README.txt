p46 (2026-11-06) — GPT 검토(11-06 17:11) 반영.
1) schemas.prepare(): 요청 전에 문서 수집(중첩 $id 기준 주소 반영) + Registry 구성·crawl + 모든 $ref 해석 확인(lookup) + check_schema +
   search_response 검증기 생성 → Prepared.  지원하지 않는 참조($dynamicRef 등)·해석 실패·조회 실패는 SchemaError → 판매자 POST 0회.
2) schemas.fetch(): GET 의 타임아웃·연결 예외 → SchemaError.  client.search() 는 준비 단계 모든 예외를 schema_unavailable 로.
3) discovery.cache_seconds(headers, now): 남은 유효 시간 = max-age − max(Age, 지금−Date) (RFC 9111).
4) explain.card_key(): UCP 카드는 호스트·상품·옵션 ID 로 — 상품명이 바뀌어도 key 동일 (변환 key == enrich 뒤 key).
반영 전 확인: 맥 파일 mtime 이 p45 반영 직후(06:19~06:20 UTC) 그대로 → 다른 작업 변경 없음, diff 삭제 줄은 모두 의도한 교체.
