"""기록(Evidence.usage)과 실제 통제의 경계 (2026-11-03 p30).

* explain.choose 는 Evidence.usage 를 읽지 않는다 → usage 는 기록이고, 차이는 selection_audit 경고로 드러낸다.
* OCR 근거(ocr_evidence)는 어떤 선택·응답 경로에도 연결돼 있지 않다 — 연결되면 이 테스트가 알린다.
* 외부 AI 호출 여부를 알 수 없으면(API_CALLS 없음·형식 불명) 0회로 보지 않는다.
"""
from __future__ import annotations

import ast
import json
from pathlib import Path

import pytest

from app.domain.commerce.requests import SearchRequest
from app.services.commerce.ocr_evidence import external_ai_calls, from_offer_result, from_region_bundle
from app.services.commerce.reselect import rechoose, to_result
from app.services.commerce.search import search_products
from tests.services.chat.conftest import FakeShopping

ROOT = Path(__file__).resolve().parents[3]
FIX = Path(__file__).parent / "fixtures"
OFFER = json.loads((FIX / "ocr_offer_example.json").read_text(encoding="utf-8"))
BUNDLE = json.loads((FIX / "ocr_bundle_example.json").read_text(encoding="utf-8"))
OCR_ONLY = {"예시몰": {"상태": "허락", "이미지 문자 판독(OCR)": "허용"}}
OCR_AND_AI = {"예시몰": dict(OCR_ONLY["예시몰"], **{"외부 AI 전송": "허용"})}
MISSING = object()


@pytest.mark.parametrize("value", [MISSING, None, "0", "2", True, False, -1, 1.5])
def test_unknown_external_ai_calls_are_not_treated_as_zero(value):
    for doc, convert in ((OFFER, from_offer_result), (BUNDLE, from_region_bundle)):
        data = {k: v for k, v in doc.items() if k != "API_CALLS"}
        if value is not MISSING:
            data["API_CALLS"] = value
        assert external_ai_calls(data) is None
        assert convert(data, partner="예시몰", permissions=OCR_ONLY)["reason"] == "no_external_ai_permission"
        ok = convert(data, partner="예시몰", permissions=OCR_AND_AI)
        assert ok["status"] == "ok" and ok["provenance"]["api_calls"] is None


def test_explicit_zero_needs_only_ocr_permission():
    for doc, convert in ((OFFER, from_offer_result), (BUNDLE, from_region_bundle)):
        res = convert(dict(doc, API_CALLS=0), partner="예시몰", permissions=OCR_ONLY)
        assert res["status"] == "ok" and res["provenance"]["api_calls"] == 0


def _imports(path: Path) -> set[str]:
    tree = ast.parse(path.read_text(encoding="utf-8"))
    out = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            out |= {a.name for a in node.names}
        elif isinstance(node, ast.ImportFrom) and node.module:
            out.add(node.module)
            out |= {f"{node.module}.{a.name}" for a in node.names}
    return out


def test_ocr_evidence_is_not_wired_into_any_app_path_yet():
    users = [p.relative_to(ROOT).as_posix() for p in (ROOT / "app").rglob("*.py")
             if p.name != "ocr_evidence.py" and any("ocr_evidence" in m for m in _imports(p))]
    assert users == [], ("OCR 근거를 쓰는 경로가 생겼어요. 그 경로가 policies.usable(…) 로 용도를 검사하는지 "
                         f"확인한 뒤 이 테스트를 갱신하세요: {users}")


def test_selection_code_does_not_read_evidence_usage():
    mods = _imports(ROOT / "app/services/chat/explain.py")
    assert not any(m.startswith("app.domain") or "ocr" in m for m in mods)


def it(n, title, price, **extra):
    return {"product_name": title, "price": price, "product_url": f"https://www.coupang.com/vp/products/{n}",
            "platform_name": "쿠팡", "is_coupang": True, **extra}


def test_fallback_snapshot_weight_is_recorded_as_unknown_and_audited():
    items = [it(1, "국산 삼겹살 구이용", 10000, weight_g=1000), it(2, "국산 삼겹살 수육용", 9000, weight_g=500),
             it(3, "국산 삼겹살 300g", 7000)]
    res = search_products(SearchRequest(text="삼겹살 추천"), shopping=FakeShopping(items=items))
    value = next(i for i in res.items if i.score.role == "value")
    weight = next(e for e in value.evidence if e.field == "weight_g")
    assert value.product.title == "국산 삼겹살 구이용"           # 선택은 그대로 (바꾸지 않음)
    assert weight.method == "unknown" and "DB 대체 경로" in weight.source
    assert {d.use: d.verdict for d in weight.usage}["price_compare"] == "block"
    assert any("'가성비' 선택(국산 삼겹살 구이용)" in w for w in res.warnings)
    titled = next(i for i in res.items if i.product.title == "국산 삼겹살 300g")
    assert next(e for e in titled.evidence if e.field == "weight_g").method == "title_parse"


def test_title_weights_give_no_audit_warning():
    items = [it(1, "국산 삼겹살 500g", 9000), it(2, "국산 삼겹살 1kg", 23000), it(3, "국산 삼겹살 2kg", 42000)]
    res = search_products(SearchRequest(text="삼겹살 추천"), shopping=FakeShopping(items=items))
    assert not [w for w in res.warnings if "가격 비교 허용 전" in w]


def test_reselected_card_without_source_is_not_called_title():
    from app.services.chat import explain
    from app.services.chat.service import item_to_card

    raw = [it(1, "국산 삼겹살 구이용", 10000, weight_g=1000), it(2, "국산 삼겹살 수육용", 9000, weight_g=500)]
    cards = [dict(explain.enrich(item_to_card(x, 0), x), query="삼겹살") for x in raw]
    res = to_result(rechoose(cards, ask="삼겹살"), query="삼겹살")
    w = next(e for i in res.items for e in i.evidence if e.field == "weight_g")
    assert w.method == "unknown" and w.source.startswith("출처 확인 불가")
    assert any("가격 비교 허용 전" in x for x in res.warnings)
