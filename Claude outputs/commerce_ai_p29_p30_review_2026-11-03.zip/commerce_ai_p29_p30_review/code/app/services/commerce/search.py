"""상품 검색·선택 서비스 — /api/chat 쇼핑 턴(ChatService._shopping_turn)과 같은 순서·같은 함수.

화면 블록·대화 상태 저장은 하지 않는다 (그건 REST 어댑터의 일).  반환은 CommerceResult.
기존 경로와 상품·순위·역할·사유가 같은지는 tests/services/chat/test_commerce_contract.py 가 고정한다.
"""
from __future__ import annotations

import logging
import math
import uuid
from collections.abc import Callable

from app.domain.commerce import policies
from app.domain.commerce.models import (
    CommerceError, CommerceResult, Evidence, Followup, Offer, Product, Provenance, ScoreDetail, ScoreReason,
    ShoppingItem,
)
from app.domain.commerce.requests import SearchRequest

log = logging.getLogger(__name__)

ENGINE = "chat.explain.choose"


def _priority(text: str, nlu_parse: Callable | None) -> str:
    """ChatService._priority 와 같은 판정 (규칙 먼저, 그다음 NLU, 없으면 ranking)."""
    from app.services.chat.service import NLU_PRIORITY, PRIORITY_RULES

    for name, pattern in PRIORITY_RULES:
        if pattern.search(text):
            return name
    parsed = None
    if nlu_parse is not None:
        try:
            parsed = nlu_parse(text)
        except Exception:  # noqa: BLE001
            parsed = None
    if parsed:
        return NLU_PRIORITY.get(parsed.get("action_intent") or "", "ranking")
    return "ranking"


def collect(req: SearchRequest, *, shopping: Callable, keyword_extractor: Callable | None = None,
            nlu_parse: Callable | None = None, annotate_prices: bool = True) -> dict:
    """기존 함수들로 카드 묶음을 만든다 (dict 그대로 — 어댑터가 화면용·공통 모델용으로 각각 투영).

    Returns {"query", "label", "terms", "priority", "budget", "picked", "partner_list", "connect", "raw", "error",
             "preview", "found", "recommendation_path"}
    """
    from app.services.chat import explain
    from app.services.chat.budget import parse_budget, strip_budget
    from app.services.chat.service import (
        ChatService, _content_tokens, _label, connect_links, item_to_card, relevant, shopping_terms,
    )
    from app.services.partners import feed as partner_feed
    from app.services.public_price import kamis

    text = req.text.strip()
    priority = req.priority or _priority(text, nlu_parse)
    budget = parse_budget(text)
    search_text = strip_budget(text) if budget and not budget.get("none") else text
    query, terms = shopping_terms(search_text, keyword_extractor)
    label = _label(query)

    raw: dict[str, dict] = {}
    error = None
    recommendation_path = None
    try:
        result = shopping(query, priority, req.session_id) or {}
        recommendation_path = result.get("recommendation_path")
        if not isinstance(recommendation_path, str):
            recommendation_path = None
        cards = []
        for it in (result.get("items") or [])[:req.limit]:
            card = dict(explain.enrich(item_to_card(it, 0), it), _q=query)
            raw[card["key"]] = it
            cards.append(card)
    except Exception as e:  # noqa: BLE001 — 같은 상황에서 웹은 '불러오지 못했어요' 안내
        log.exception("shopping provider failed")
        cards, error = [], CommerceError(code="source_unavailable", message=f"'{query}' 상품을 불러오지 못했어요.",
                                         scope="source", source="shopping")
    if terms:
        cards = [c for c in cards if relevant(c["title"], terms)]

    partner_terms = terms or _content_tokens(label)
    partner_cards = [ChatService._partner_card(it, query) for it in
                     (partner_feed.offers(lambda t: relevant(t, partner_terms)) if partner_terms else [])]
    cards = cards + [c for c in partner_cards if c["partner_mode"] == "compare"]
    partner_list = [c for c in partner_cards if c["partner_mode"] == "list"]
    preview = any(c.get("partner_preview") for c in partner_cards)

    connect_terms = terms or _content_tokens(label)
    connect = (connect_links(connect_terms)
               if connect_terms and not policies.is_alcohol_request(text) else [])

    found = len(cards)                          # 견준 후보 수 (화면 머리말 '후보 n개를 같은 기준으로…')
    picked = None
    if cards:
        picked = explain.choose(cards, budget=budget, ask=text)
        if annotate_prices:                     # _result_blocks 와 같은 순서: 고른 뒤 시세 참고 한 줄
            kamis.annotate(picked["picks"] + picked["others"])
        for c in picked["picks"] + picked["others"]:
            if c.get("partner_note") and c["partner_note"] not in (c.get("why") or []):
                c["why"] = (c.get("why") or []) + [c["partner_note"]]
        start = max([c["rank"] for c in picked["picks"] + picked["others"]] or [0])
        partner_list = [dict(c, rank=start + n, why=[c["partner_note"]]) for n, c in enumerate(partner_list, 1)]
        start = max([start] + [c["rank"] for c in partner_list])
        connect = [dict(c, rank=start + n) for n, c in enumerate(connect, 1)]
    else:
        partner_list = []                       # 웹도 쿠팡 결과가 없으면 업체 목록을 보여 주지 않는다
        connect = [dict(c, rank=n) for n, c in enumerate(connect, 1)]
    return dict(query=query, label=label, terms=terms, priority=priority, budget=budget, picked=picked,
                partner_list=partner_list, connect=connect, raw=raw, error=error, preview=preview, found=found,
                recommendation_path=recommendation_path)


# ── 공통 모델로 투영 ───────────────────────────────────────

def _int(v) -> int | None:
    try:
        return None if v is None else int(round(float(v)))
    except (TypeError, ValueError):
        return None


def _reasons(card: dict) -> list[ScoreReason]:
    out = []
    for w in card.get("why") or []:
        if isinstance(w, dict) and w.get("text"):
            out.append(ScoreReason(text=str(w["text"]), basis=str(w.get("basis") or "")))
        elif isinstance(w, str) and w:
            out.append(ScoreReason(text=w, basis=""))
    if not out and card.get("reason"):
        out.append(ScoreReason(text=str(card["reason"]), basis="source"))
    return out


def _upstream_weight(item: dict | None) -> float | None:
    """explain._amount 와 같은 규칙으로 상위 weight_g 를 읽는다 (1g~200kg 밖이면 무시)."""
    value = (item or {}).get("weight_g")
    try:
        value = float(value) if value not in (None, "") else None
    except (TypeError, ValueError):
        return None
    return value if value and 1 <= value <= 200_000 else None


def _evidence(card: dict, item: dict | None) -> list[Evidence]:
    ev: list[Evidence] = []
    mall = card.get("mall") or None
    if card.get("weight_g"):
        # 2026-11-03 p30: explain._amount 는 상위 결과의 weight_g 를 먼저 쓰고, 없을 때만 상품명에서 읽는다.
        # 상위 weight_g 는 DB 대체 경로(main.py: online_food_price_snapshot.weight_g)에서만 채워지며 출처 미확인.
        # 상품명에서 같은 값이 읽히면 '상품명 표기', 아니면 출처 미확인(unknown)으로 기록한다.
        from app.services.chat.explain import parse_units

        weight = float(card["weight_g"])
        title_weight = parse_units(card.get("title") or "")[1]
        if title_weight is not None and abs(title_weight - weight) < 1e-6:
            method, source = "title_parse", "상품명 표기"
        elif _upstream_weight(item) is not None and abs(_upstream_weight(item) - weight) < 1e-6:
            method, source = "unknown", "상위 추천 결과 weight_g (DB 대체 경로 snapshot)"
        else:
            method, source = "unknown", "출처 확인 불가 (저장된 후보 등)"
        ev.append(Evidence(field="weight_g", value=f"{weight:g}", unit="g", method=method, source=source))
    if card.get("unit_count"):
        ev.append(Evidence(field="unit_count", value=str(card["unit_count"]), unit="개", method="title_parse",
                           source="상품명 표기"))
    if card.get("rocket") is not None:
        ev.append(Evidence(field="rocket", value=str(card["rocket"]).lower(), method="api", source=mall))
    if card.get("free_shipping") is not None:
        ev.append(Evidence(field="free_shipping", value=str(card["free_shipping"]).lower(), method="api", source=mall))
    # 출처 미확인. 상위 순서/DB fallback의 간접 소비 여부는 별도이며 이 projection은 차단을 보장하지 않는다.
    item = item or {}
    for name in ("rating", "review_count"):
        if item.get(name) not in (None, "", 0):
            ev.append(Evidence(field=name, value=str(item[name]), method="unknown", source=mall))
    if card.get("partner"):
        ev.append(Evidence(field="price", value=str(card.get("price")), unit="원", method="partner_feed",
                           source=card["partner"], collected_at=card.get("seen_at")))
    if card.get("affiliate_program") == policies.CONNECT_PROGRAM:
        ev.append(Evidence(field="price", value=str(card.get("price")), unit="원", method="registry",
                           source="쇼핑커넥트 등록부"))
    # 2026-11-03 p29: 용도별 판정을 붙인다 (판정 규칙은 policies.decide_usage 한 곳)
    compare_ok = card.get("partner_mode") == "compare"
    return [policies.with_usage(e, partner_compare_allowed=compare_ok) for e in ev]


UPSTREAM_SCORE_FIELDS = ("score", "final_score", "v8_final_score", "v7_final_score",
                         "final_recommendation_score", "adaptive_score")


def _finite_score(value) -> float | None:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return None
    try:
        number = float(value)
    except (ValueError, OverflowError):
        return None
    return number if math.isfinite(number) else None


def to_item(card: dict, section: str, item: dict | None = None,
            recommendation_path: str | None = None) -> ShoppingItem:
    from app.services.chat import explain

    key = card.get("key") or explain.card_key(card)
    merchant = card.get("source")
    if merchant in (None, "", "판매처", card.get("mall")):
        merchant = None
    if card.get("partner"):
        link_type = "partner"
    elif card.get("affiliate"):
        link_type = "affiliate"
    else:
        link_type = "direct"
    item = item or {}
    engine_score = item.get("final_score", item.get("v8_final_score"))
    upstream_scores = {name: number for name in UPSTREAM_SCORE_FIELDS
                       if (number := _finite_score(item.get(name))) is not None}
    fallback_used = ({"canonical_provider": False, "db_fallback": True}.get(recommendation_path)
                     if item else None)
    upstream_rank = item.get("rank")
    if isinstance(upstream_rank, bool) or not isinstance(upstream_rank, int):
        upstream_rank = None
    return ShoppingItem(
        section=section,
        product=Product(product_id=card.get("pid"), key=key, title=card.get("title") or "",
                        image_url=policies.safe_url(card.get("image")), weight_g=card.get("weight_g"),
                        unit_count=card.get("unit_count"), seller_claims=list(card.get("seller_claims") or [])),
        offer=Offer(platform=str(card.get("mall") or ""), merchant=merchant,
                    product_url=policies.safe_url(card.get("url")), price_krw=_int(card.get("price")) or 0,
                    shipping_krw=_int(card.get("shipping_fee")), total_krw=_int(card.get("total")),
                    per100g_krw=_int(card.get("per100g")), per_unit_krw=_int(card.get("per_unit")),
                    rocket=card.get("rocket"), free_shipping=card.get("free_shipping"), link_type=link_type,
                    affiliate_program=card.get("affiliate_program"), opens_directly=bool(card.get("direct")),
                    seen_at=card.get("seen_at")),
        score=ScoreDetail(rank=int(card.get("rank") or 0), role=card.get("role"), role_label=card.get("role_label"),
                          reasons=_reasons(card), engine=ENGINE if section in ("picks", "others") else section,
                          engine_score=_finite_score(engine_score), upstream_scores=upstream_scores,
                          upstream_rank=upstream_rank, fallback_used=fallback_used),
        evidence=_evidence(card, item),
        price_reference=card.get("market_ref"),
    )


def search_products(req: SearchRequest, *, shopping: Callable, keyword_extractor: Callable | None = None,
                    nlu_parse: Callable | None = None, annotate_prices: bool = True,
                    request_id: str | None = None) -> CommerceResult:
    got = collect(req, shopping=shopping, keyword_extractor=keyword_extractor, nlu_parse=nlu_parse,
                  annotate_prices=annotate_prices)
    raw, picked = got["raw"], got["picked"]
    items: list[ShoppingItem] = []
    if picked:
        items += [to_item(c, "picks", raw.get(c["key"]), got["recommendation_path"]) for c in picked["picks"]]
        items += [to_item(c, "others", raw.get(c["key"]), got["recommendation_path"]) for c in picked["others"]]
    items += [to_item(c, "partner_list") for c in got["partner_list"]]
    items += [to_item(c, "connect") for c in got["connect"]]

    warnings = ["평점·후기·도착일은 쿠팡·네이버 검색 API가 제공하지 않아요. 판매처 페이지에서 확인해 주세요."]
    if picked and picked["budget_miss"]:
        warnings.append(f"예산 {got['budget']['label']} 안에 드는 후보가 없어 가격이 낮은 순으로 보여 줍니다.")
    if got["preview"]:
        warnings.append("미리 보기: 업체 상품은 허락 전 예시 데이터예요. 실제 상품·가격이 아니에요.")
    if got["connect"]:
        warnings.append("쇼핑커넥트 등록 상품은 위 후보와 같은 기준으로 견주지 않았고, 가격은 등록 시점 값이에요.")
    warnings += selection_audit(items)

    followup = None
    if picked and not got["budget"]:
        followup = Followup(kind="budget", question="예산이 있으면 알려 주세요. 예: 3만원 이하, 5만원 정도, 10만원대")

    errors = [got["error"]] if got["error"] else []
    if errors and items:
        status = "partial"
    elif errors:
        status = "error"
    elif items:
        status = "ok"
    else:
        status = "empty"
    programs = [i.offer.affiliate_program for i in items if i.offer.link_type == "affiliate"]
    return CommerceResult(
        request_id=request_id or str(uuid.uuid4()), status=status, items=items, followup=followup,
        warnings=warnings if items else [], disclosure=policies.disclosure_for(programs),
        provenance=Provenance(sources=sorted({i.offer.platform for i in items if i.offer.platform}), engine=ENGINE,
                              recommendation_path=got["recommendation_path"],
                              query=got["query"], terms=got["terms"]),
        errors=errors)


AUDITED_ROLES = {"value": "가성비", "ample": "넉넉한 양"}


def selection_audit(items: list[ShoppingItem]) -> list[str]:
    """기록과 실제 선택의 차이를 드러낸다 (2026-11-03 p30) — 선택을 바꾸지는 않는다.

    explain.choose 는 Evidence.usage 를 읽지 않는다.  중량을 근거로 고른 역할(가성비·넉넉한 양)의 중량이
    정책상 가격 비교 허용(allow·allow_labelled)이 아니면 경고를 남긴다.  선택에서 빼는 것은 사용자 결정 사항."""
    out = []
    for i in items:
        if i.score.role not in AUDITED_ROLES:
            continue
        weight = next((e for e in i.evidence if e.field == "weight_g"), None)
        if weight is None:
            continue
        decision = next((d for d in weight.usage if d.use == "price_compare"), None)
        if decision is None or decision.verdict not in ("allow", "allow_labelled"):
            out.append(f"'{AUDITED_ROLES[i.score.role]}' 선택({i.product.title})에 가격 비교 허용 전인 중량 값"
                       f"({weight.source})이 쓰였어요. 선택은 바꾸지 않았어요.")
    return out

