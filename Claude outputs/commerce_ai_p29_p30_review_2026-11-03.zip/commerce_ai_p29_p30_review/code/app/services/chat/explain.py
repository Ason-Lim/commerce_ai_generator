"""'왜 이 상품인가' — 추천 사유를 계산으로만 만든다 (2026-11-01).

검색 결과를 순서대로 보여 주면 판매처 검색과 다를 게 없다.  후보 전체를 같은 기준으로 견준 뒤
역할이 다른 상품을 하나씩 고른다:

    value  가성비     100g당(또는 개당) 가격이 가장 낮은 상품 — 비교할 양이 없으면 '최저가'
    fast   빠른 배송  판매처가 '로켓배송'으로 표시한 상품 중 가장 저렴한 것
    ample  넉넉한 양  용량이 가장 큰 상품 (가성비 상품보다 30% 이상 많을 때만)
    gift   선물용     선물을 찾는 말이 있고, 상품명에 선물세트 등의 표기가 있을 때 (판매자 표기)
    alt    다른 선택  역할이 겹쳐 빈자리를 채우는 후보

사유(why)의 근거(basis)는 셋 중 하나다 — 화면은 이 구분을 그대로 보여 준다.
    calc  우리가 후보끼리 계산한 값 (상품명 표기 중량·판매가 기준)
    mall  판매처 API가 준 표시 (로켓배송·무료배송)
    you   고객이 말한 조건 (예산)

판매자 문구(고당도·1++·국내산 …)는 사유·순서에 쓰지 않고 seller_claims 로만 따로 내려 보낸다.
평점·후기·도착일은 쿠팡·네이버 검색 API가 주지 않는다 → 만들지 않고 판매처 확인 안내(check_at_mall).
"""
from __future__ import annotations

import hashlib
import re

from app.services.chat.budget import fits

# app.admin.shared.markets.base.parse_units 와 같은 규칙 — 대화 서비스가 관리자 패키지(pydantic)를 불러오지 않도록 옮겨 둠
_UNIT_RE = re.compile(r"(\d+)\s*(?:개입|개|입|팩|봉|구)\b")
_WEIGHT_RE = re.compile(r"(\d+(?:\.\d+)?)\s*(kg|g)\b", re.IGNORECASE)


def parse_units(title: str) -> tuple[int | None, float | None]:
    """상품명에서 개입 수·중량(g)을 읽는다 (상품명 표기 그대로)."""
    m = _UNIT_RE.search(title or "")
    unit = int(m.group(1)) if m else None
    w = _WEIGHT_RE.findall(title or "")
    weight = float(w[-1][0]) * (1000 if w[-1][1].lower() == "kg" else 1) if w else None
    return unit, weight

ROLE_LABEL = {"value": "가성비", "lowest": "최저가", "fast": "빠른 배송", "ample": "넉넉한 양",
              "gift": "선물용", "alt": "다른 선택"}
MAX_PICKS = 4

_CLAIMS = (
    ("고당도", re.compile(r"고당도|꿀\s*당도|당도\s*\d+\s*(?:brix|브릭스)?", re.I)),
    ("등급 표기", re.compile(r"1\+\+|1\+\s*등급|투뿔|1등급|특등급")),
    ("국내산 표기", re.compile(r"국내산|(?<![가-힣])국산(?!화)|우리\s*농산물")),
    ("평점 표기", re.compile(r"평점\s*\d|별점\s*\d|만족도\s*\d|리뷰\s*\d|후기\s*\d")),
    ("산지직송", re.compile(r"산지\s*직송|산지직배송|농장\s*직송")),
    ("프리미엄", re.compile(r"프리미엄|명품|최상급|특상|특품|로얄")),
    ("유기농·무농약", re.compile(r"유기농|무농약|친환경|무항생제")),
    ("선물 포장", re.compile(r"선물\s*세트|선물세트|선물용|보자기|선물\s*포장|쇼핑백")),
    ("HACCP", re.compile(r"HACCP|해썹", re.I)),
)
_GIFT_TITLE = re.compile(r"선물\s*세트|선물세트|선물용|명절|보자기|쇼핑백|선물\s*포장")
_GIFT_ASK = re.compile(r"선물|부모님|명절|추석|설날|답례|집들이|어버이")


def won(v: int | float | None) -> str:
    return "미확인" if v is None else f"{int(round(v)):,}원"


def card_key(card: dict) -> str:
    raw = "|".join(str(card.get(k) or "") for k in ("mall", "pid", "url", "title"))
    return hashlib.sha1(raw.encode("utf-8")).hexdigest()[:12]


def seller_claims(title: str) -> list[str]:
    return [label for label, rx in _CLAIMS if rx.search(title or "")]


def _amount(card: dict, item: dict) -> tuple[float | None, int | None]:
    weight = item.get("weight_g")
    try:
        weight = float(weight) if weight not in (None, "") else None
    except (TypeError, ValueError):
        weight = None
    unit, w2 = parse_units(card.get("title") or "")
    if not weight and w2:
        weight = w2
    if weight is not None and not (1 <= weight <= 200_000):
        weight = None
    return weight, unit


def _basis(card: dict) -> int:
    return card["total"] if card.get("total") is not None else card.get("price") or 0


def _flag(item: dict, *names) -> bool | None:
    for n in names:
        v = item.get(n)
        if isinstance(v, bool):
            return v
    return None


def enrich(card: dict, item: dict) -> dict:
    """사실만 붙인다: 키 · 중량/개수 · 100g당 · 로켓/무료배송 표시 · 판매자 문구 · 판매처 확인 안내."""
    weight, unit = _amount(card, item)
    rocket = _flag(item, "is_rocket", "isRocket")
    free = _flag(item, "is_free_shipping", "isFreeShipping")
    if free is True and card.get("shipping_fee") is None:
        card["shipping_fee"] = 0
        card["total"] = card.get("price")
    card.update(
        key=card_key(card),
        weight_g=weight,
        unit_count=unit,
        per100g=round(_basis(card) / weight * 100) if weight and _basis(card) else None,
        per_unit=round(_basis(card) / unit) if unit and unit > 1 and _basis(card) else None,
        rocket=rocket,
        free_shipping=free,
        seller_claims=seller_claims(card.get("title") or ""),
        check_at_mall=True,
        delivery_hint="로켓배송 표시" if rocket else ("무료배송 표시" if free else None),
    )
    return card


def _weight_text(g: float) -> str:
    return f"{g / 1000:g}kg" if g >= 1000 else f"{g:g}g"


def choose(cards: list[dict], *, budget: dict | None = None, ask: str = "") -> dict:
    """역할별로 고르고 사유를 단다.

    Returns {"picks": [...], "others": [...], "pool": n, "total": n, "budget_miss": bool}
    """
    priced = [c for c in cards if (c.get("price") or 0) > 0]
    pool = [c for c in priced if fits(_basis(c), budget)]
    budget_miss = bool(budget and not budget.get("none") and priced and not pool)
    if budget_miss:          # 예산 안에 없으면: 예산에 가까운(싼) 순으로, 그렇다고 말한다
        pool = sorted(priced, key=_basis)
    n = len(pool)
    picks: list[dict] = []

    def take(card, role, text, basis):
        card = dict(card, role=role, role_label=ROLE_LABEL[role], why=[{"text": text, "basis": basis}])
        picks.append(card)
        return card

    def free_(c):
        return all(p["key"] != c["key"] for p in picks)

    # 1) 가성비 — 100g당 비교가 가능한 후보가 2개 이상일 때만 '가성비'라고 부른다
    weighed = [c for c in pool if c.get("per100g")]
    counted = [c for c in pool if c.get("per_unit")]
    value = None
    if len(weighed) >= 2:
        best = min(weighed, key=lambda c: c["per100g"])
        value = take(best, "value", f"후보 {len(weighed)}개 중 100g당 가장 저렴해요 ({won(best['per100g'])}/100g)", "calc")
    elif len(counted) >= 2:
        best = min(counted, key=lambda c: c["per_unit"])
        value = take(best, "value", f"후보 {len(counted)}개 중 개당 가격이 가장 낮아요 (개당 {won(best['per_unit'])})", "calc")
    elif pool:
        best = min(pool, key=_basis)
        value = take(best, "lowest", f"후보 {n}개 중 가격이 가장 낮아요" if n > 1 else "조건에 맞는 후보가 이 상품 하나예요", "calc")

    # 2) 빠른 배송 — 판매처의 '로켓배송' 표시 (도착일 약속은 아님)
    rockets = [c for c in pool if c.get("rocket") and free_(c)]
    if rockets:
        best = min(rockets, key=_basis)
        others = sum(1 for c in pool if c.get("rocket"))
        take(best, "fast", "쿠팡이 로켓배송으로 표시한 상품" + (" 중 가장 저렴해요" if others > 1 else "이에요"), "mall")

    # 3) 넉넉한 양
    if value and value.get("weight_g"):
        bigger = [c for c in weighed if free_(c) and c["weight_g"] >= value["weight_g"] * 1.3]
        if bigger:
            best = max(bigger, key=lambda c: (c["weight_g"], -c["per100g"]))
            take(best, "ample", f"후보 중 양이 가장 많아요 ({_weight_text(best['weight_g'])}, 100g당 {won(best['per100g'])})", "calc")

    # 4) 선물용 — 고객이 선물을 찾을 때만, 판매자 표기임을 밝힌다
    if _GIFT_ASK.search(ask or ""):
        gifts = [c for c in pool if free_(c) and _GIFT_TITLE.search(c.get("title") or "")]
        if gifts:
            best = min(gifts, key=_basis)
            take(best, "gift", "상품명에 선물 포장·세트 표기가 있어요 (판매자 표기)", "mall")

    # 5) 남은 자리 — 원래 검색 순서대로
    for c in pool:
        if len(picks) >= MAX_PICKS:
            break
        if free_(c):
            diff = _basis(c) - _basis(picks[0]) if picks else 0
            text = (f"{ROLE_LABEL[picks[0]['role']]} 상품보다 {won(abs(diff))} {'비싸요' if diff > 0 else '저렴해요'}"
                    if picks and diff else "다른 구성으로 비교해 볼 만한 후보예요")
            take(c, "alt", text, "calc")

    picks = picks[:MAX_PICKS]
    for p in picks:
        extra = []
        if budget and not budget.get("none") and not budget_miss:
            if p.get("total") is not None:
                extra.append({"text": f"예산 {budget['label']} 안이에요 (배송비 포함 {won(p['total'])})", "basis": "you"})
            else:
                extra.append({"text": f"상품가 기준 예산 {budget['label']} 안이에요 · 배송비는 미확인", "basis": "you"})
        if p.get("weight_g") and p["role"] not in ("value", "ample"):
            per = f", 100g당 {won(p['per100g'])}" if p.get("per100g") else ""
            extra.append({"text": f"{_weight_text(p['weight_g'])}{per} (상품명 표기 기준)", "basis": "calc"})
        if p.get("rocket") and p["role"] != "fast":
            extra.append({"text": "쿠팡 로켓배송 표시 상품", "basis": "mall"})
        if p.get("free_shipping") and not p.get("rocket"):
            extra.append({"text": "무료배송 표시 상품", "basis": "mall"})
        p["why"] = (p["why"] + extra)[:3]
        p["reason"] = p["why"][0]["text"]
        p["evidence"] = []          # 근거 없는 설명 문구(판매 주장 포함)는 ✓ 근거로 내보내지 않는다

    chosen = {p["key"] for p in picks}
    others = []
    for c in cards:
        if c["key"] in chosen:
            continue
        why = []
        if budget and not budget.get("none") and not budget_miss and not fits(_basis(c), budget):
            why = [{"text": f"예산 {budget['label']} 밖이에요 ({won(_basis(c))})", "basis": "you"}]
        others.append(dict(c, role=None, role_label=None, why=why, reason=why[0]["text"] if why else "", evidence=[]))
    for rank, c in enumerate(picks + others, 1):
        c["rank"] = rank
    return {"picks": picks, "others": others, "pool": n, "total": len(priced), "budget_miss": budget_miss}


def criteria_line(picks: list[dict], budget: dict | None) -> str:
    used = []
    roles = {p["role"] for p in picks}
    if "value" in roles:
        used.append("100g당 가격")
    elif "lowest" in roles:
        used.append("가격")
    if "fast" in roles:
        used.append("로켓배송 표시")
    if "ample" in roles:
        used.append("용량")
    if "gift" in roles:
        used.append("선물 표기")
    if budget and not budget.get("none"):
        used.append(f"예산 {budget['label']}")
    return " · ".join(used)
