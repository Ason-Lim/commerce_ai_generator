"""MCP 도구 2개의 몸체 — 프로토콜(mcp 패키지)을 모른다.  server.py 가 이 함수들을 도구로 등록한다.

food_search_products(text, limit)        → 공통 서비스 search_products 결과(commerce.v1)를 그대로 투영
food_get_recipe(recipe_id | dish_name)   → 공통 서비스 get_recipe 결과(commerce.v1)를 그대로 투영

제휴 링크 원칙 (2026-11-02)
* 쿠팡 파트너스·네이버 쇼핑커넥트 링크를 AI 에이전트를 거쳐 보여 줘도 되는지 아직 확인하지 않았다.
  → MCP_AFFILIATE_LINKS=1 이 아니면 제휴 상품의 링크(product_url)를 비우고, 쇼핑커넥트 등록 목록은 빼고,
    그 사실을 warnings 에 적는다.  상품·가격·순위·사유는 웹과 같다.
* 순위는 바꾸지 않는다 (링크를 빼도 rank 는 그대로).
"""
from __future__ import annotations

import os
from collections.abc import Callable

from app.domain.commerce.requests import RecipeRequest, SearchRequest

AFFILIATE_HELD = ("제휴(수수료) 링크는 AI 에이전트 경유 표시 허용 여부를 확인 중이라 비워 두었어요. "
                  "상품 이름으로 판매처에서 찾아보시거나 웹 화면에서 이용해 주세요.")


def affiliate_links_allowed(env=None) -> bool:
    source = os.environ if env is None else env
    return (source.get("MCP_AFFILIATE_LINKS") or "0").strip() == "1"


def _hold_affiliate(data: dict) -> dict:
    items, held = [], False
    for it in data.get("items") or []:
        offer = it.get("offer") or {}
        if it.get("section") == "connect":            # 등록부 목록은 전부 제휴 링크
            held = True
            continue
        if offer.get("link_type") == "affiliate" and offer.get("product_url"):
            it = dict(it, offer=dict(offer, product_url=None))
            held = True
        items.append(it)
    if held:
        data = dict(data, items=items, warnings=list(data.get("warnings") or []) + [AFFILIATE_HELD])
    return data


def food_search_products(text: str, limit: int = 10, *, shopping: Callable,
                         keyword_extractor: Callable | None = None, nlu_parse: Callable | None = None,
                         env=None) -> dict:
    from app.services.commerce.search import search_products

    req = SearchRequest(text=(text or "").strip()[:500] or " ", limit=max(1, min(int(limit or 10), 10)))
    data = search_products(req, shopping=shopping, keyword_extractor=keyword_extractor,
                           nlu_parse=nlu_parse).model_dump(mode="json")
    return data if affiliate_links_allowed(env) else _hold_affiliate(data)


def food_get_recipe(recipe_id: str | None = None, dish_name: str | None = None, *, resolver) -> dict:
    from app.services.commerce.recipes import get_recipe

    req = RecipeRequest(recipe_id=(recipe_id or None), dish_name=(dish_name or None))
    return get_recipe(req, resolver=resolver).model_dump(mode="json")
