"""commerce_ai MCP 서버 — 로컬 stdio 전용 (내부 검증 1단계).

    pip install "mcp>=1.2"
    python -m app.mcp_adapter.server            # Claude Desktop 등에서 stdio 로 실행

원격(HTTP) 공개는 하지 않는다: 요청 제한·키 검증·제휴 링크 정책 확인이 먼저다.
웹(/api/chat)과 같은 서비스 설정(build_default_service)을 쓰므로 판매처 키·DB 는 서버 .env 그대로다.
"""
from __future__ import annotations

import functools
import os

from app.mcp_adapter import tools

NAME = "commerce-ai-food"
INSTRUCTIONS = ("식품 쇼핑 후보와 공공 레시피를 찾는 도구예요. 결과의 순위·사유·고지(disclosure)·경고(warnings)를 "
                "바꾸지 말고 함께 보여 주세요. 배송비가 null 이면 0원이 아니라 '미확인'이에요. "
                "AI 제안 레시피(source_level=ai_suggestion)는 원문이 아니라고 밝혀 주세요.")


@functools.lru_cache(maxsize=1)
def _service():
    try:
        from dotenv import load_dotenv

        load_dotenv(os.path.join(os.path.dirname(__file__), "..", "..", ".env"))
    except ImportError:
        pass
    from app.api.chat_routes import build_default_service

    return build_default_service()


def _nlu_parse(text: str):
    nlu = _service()._nlu()
    return nlu.parse(text) if nlu is not None else None


def search_products(text: str, limit: int = 10) -> dict:
    """식품 상품 후보 검색. text 는 고객 문장 그대로 (예: '5만원 이하 한우 등심'). limit 1~10."""
    svc = _service()
    return tools.food_search_products(text, limit, shopping=svc.shopping, keyword_extractor=svc.keyword_extractor,
                                      nlu_parse=_nlu_parse)


def get_recipe(recipe_id: str | None = None, dish_name: str | None = None) -> dict:
    """공공 레시피 조회. recipe_id(예: 'EPIS:467') 또는 dish_name(예: '크림파스타') 중 하나.
    이름이 여러 레시피에 맞으면 status=needs_followup 과 후보(followup.options)를 돌려준다."""
    return tools.food_get_recipe(recipe_id, dish_name, resolver=_service().recipe.resolver)


def build():
    try:                                            # mcp 2.x
        from mcp.server import MCPServer as Server
    except ImportError:                             # mcp 1.x
        from mcp.server.fastmcp import FastMCP as Server
    server = Server(NAME, instructions=INSTRUCTIONS)
    ro = _read_only()
    server.tool(name="food_search_products", annotations=ro)(search_products)
    server.tool(name="food_get_recipe", annotations=ro)(get_recipe)
    return server


def _read_only():
    """두 도구 모두 읽기 전용 — 결제·주문·저장 도구는 의도적으로 없다."""
    from mcp.types import ToolAnnotations

    try:
        return ToolAnnotations(read_only_hint=True, destructive_hint=False, open_world_hint=True)   # 2.x
    except Exception:  # noqa: BLE001
        return ToolAnnotations(readOnlyHint=True, destructiveHint=False, openWorldHint=True)       # 1.x


def main() -> None:
    build().run()          # stdio


if __name__ == "__main__":
    main()
