# commerce_ai p29·p30 검토 패키지 (2026-11-03)

GPT 검토(11-03 11:11)에 대한 응답과 근거. 코드는 맥 원본(`/Users/mom/commerce_ai_generator`)의 현재 파일 사본이며 커밋하지 않았다.
비밀키·.env·data/·개인 세션 데이터는 넣지 않았다(비밀키 패턴 검색 0건). 테스트 fixture 의 '예시몰'은 가상 업체이며 값은 지어낸 것이다.

## 1. 테스트 기준 수치 — 문서 오기였다
프로젝트 문서에 "p29 = p28 기준 5,044 passed"로 적은 것은 잘못이다. 실제 로그(`test_logs/`, 같은 Linux 복사본):

| 시점 | 결과 | 증가 | 늘어난 테스트 |
|---|---|---|---|
| p28 적용 전 | 11 failed / 5,044 passed | | |
| p28 적용 후 = p29 기준 | 11 failed / 5,060 passed | +16 | test_commerce_provenance 16 |
| p29 작업 1 후 | 11 failed / 5,065 | +5 | test_reselect_golden 1 + test_commerce_reselect 4 |
| p29 작업 2 후 | 11 failed / 5,077 | +12 | test_evidence_usage 12 |
| p29 작업 3 후 | 11 failed / 5,087 | +10 | test_ocr_evidence 10 |
| p30 후 | 7 failed / 5,105 | +18 | test_usage_enforcement 14 + 아래 4 |

- p29 의 각 단계는 p28 후(5,060)를 기준으로 비교했고, 실패 11개 목록이 매번 동일했다. provenance 16개는 계속 포함되어 있다.
- p30 실행에서는 그동안 복사본에서만 실패하던 관리자 테스트 4개(test_admin_b2b 2, test_admin_gift_monitor 1, test_proposal_templates 1)가 통과했다. p30 직전 맥 원본에서 app/·tests/ 를 다시 복사한 뒤의 실행이며, 맥 원본의 app/·tests/ 는 p29 이후 바뀐 파일이 없다(파일 시각 검사). 정확한 원인은 확인하지 못했다. p30 은 관리자 코드를 건드리지 않았다. 나머지 실패 7개 목록은 그대로다.
- 맥 원본 폴더에서 커머스 관련 테스트 7개 파일 77 passed (`commerce_tests_verbose_mac_folder.txt`). 맥 `.venv`(Python 3.14) 실행은 아직 아니다 — 모두 Linux Python 3.10.

## 2. 기록(Evidence.usage)과 실제 통제 — 지적이 맞다, p30 에서 드러내기까지 함
- `Evidence.usage` 를 읽는 코드는 없다(정적 검색). `explain.choose` 는 카드 dict 만 본다.
- **새로 확인한 사실**: `explain._amount` 는 상위 결과의 `weight_g` 를 먼저 쓰고 없을 때만 상품명에서 읽는다. 상위 `weight_g` 는 `app/main.py` DB 대체 경로(`online_food_price_snapshot.weight_g` → `db_weight_g`)에서만 채워진다. p29 는 모든 중량을 '상품명 표기(title_parse)'로 기록했는데 이는 틀렸다.
- p30 수정(`search._evidence`): 상품명에서 같은 값이 읽히면 title_parse, 상위 weight_g 와 같으면 `unknown`(DB 대체 경로 snapshot), 둘 다 아니면(저장 후보 재선택 등) `unknown`(출처 확인 불가). unknown 은 price_compare=block.
- p30 `selection_audit()`: 가성비·넉넉한 양 역할을 정한 중량이 price_compare 허용이 아니면 결과 warnings 에 경고. **선택은 바꾸지 않는다** — 막을지는 사용자 결정 사항.
- OCR 근거와 선택 경로가 섞이지 않음: `ocr_evidence` 를 import 하는 app 모듈이 없다는 것을 AST 가드 테스트로 고정(`test_usage_enforcement.py`). 연결되면 테스트가 실패하며, 그때 그 경로가 `policies.usable()` 를 거치는지 확인해야 한다. `explain.py` 는 `app.domain`·OCR 을 import 하지 않음도 고정.

## 3. OCR 허락 검사와 API_CALLS
- 허락: 상태='허락' + '이미지 문자 판독(OCR)'='허용' 열. 이미지 표시 허락만으로는 거부(테스트 3가지).
- **p30 수정**: `API_CALLS` 가 정수 0 이상일 때만 그 값을 믿는다. 키 없음·None·문자열("0" 포함)·bool·음수·소수 → 알 수 없음(None) → '외부 AI 전송' 허락이 있어야 변환. provenance.api_calls 도 기본값 0 대신 None 으로 남긴다. 명시적 0 만 OCR 허락으로 충분(테스트 16개 조합).

## 4. 남은 일
- 상위 weight_g·평점·후기 값의 출처 확정(snapshot 행의 수집 방식) → 그다음 가성비 선택에서 제외할지 결정
- 사람 검증 절차(unverified → verified 를 누가·무엇으로·어디에 기록)
- 맥 `.venv` 전체 테스트, MCP 실제 클라이언트 연결·인증 검증
- 공개 계약(commerce.v1·상태 6종)과 기존 versioned envelope 대조 — 기존 설계 위치를 알려 주면 진행

## 5. 구성
- `code/` 관련 소스·테스트·fixture 현재본 (commerce_ai_local_ocr 포함)
- `diffs/` p29 작업별·p30 diff (기존 파일 변경분; 새 파일은 code/ 참고)
- `test_logs/` 단계별 전체 테스트 요약(실패 목록 + 합계)
