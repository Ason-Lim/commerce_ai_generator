#!/usr/bin/env python3
"""검색량 급상승 리포트 만들기 (하루 1회 — 데이터랩은 전날까지의 일별 지수).

데이터랩 급상승 → 블로그 탐지 → 구글 트렌드 → 교차 확인 → var/trends/surge_YYYY-MM-DD.json
필요한 .env: NAVER_CLIENT_ID, NAVER_CLIENT_SECRET, NAVER_DAILY_DIR(식품 순위 CSV 폴더),
            GOOGLE_DATA_DIR(구글 트렌드 CSV 폴더, 선택), DEEPSEEK_API_KEY/DEEPSEEK_MODEL(원인 추정, 선택)
실행: .venv/bin/python -m scripts.update_trend_surge [--top 500]
"""
from __future__ import annotations

import argparse

from app.services.trends import surge


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--top", type=int, default=500)
    args = ap.parse_args()
    db = None
    try:
        from app.services.chat.service import engine_db

        db = engine_db()
    except Exception:  # noqa: BLE001 — customer search words are optional
        pass
    report = surge.run_from_env(db=db, top=args.top)
    print(f"데이터 기준일 {report['data_until']} · 감시 {report['universe']['total']}개 · 데이터랩 호출 {report['datalab']['calls']}회"
          + (f" · 오류 {len(report['datalab']['errors'])}건" if report["datalab"]["errors"] else ""))
    for it in report["items"][:15]:
        print(f"  {it['status']:8} {it['keyword']:<16} 평소의 {it['ratio_recent']:>5.1f}배 (최고 {it['ratio_peak']:.1f}배)"
              f" · 시작 {it['onset'] or '-'} · 교차 {it['cross']['n']}/{it['cross']['of']}")
    print("저장:", surge.report_dir() / f"surge_{report['generated_at'][:10]}.json")


if __name__ == "__main__":
    main()
