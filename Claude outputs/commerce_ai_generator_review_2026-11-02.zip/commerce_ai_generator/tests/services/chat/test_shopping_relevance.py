"""쇼핑 검색어·관련성 (2026-10-31): 문장 전체를 검색어로 보내 핫팩·노트북이 추천되던 문제.

* 조건이 붙은 문장은 상품어('휘태커스초콜릿')로 검색하고, 결과는 그 말과 겹쳐야만 보여 준다.
* 관련 상품이 없으면 그렇다고 말하고, 네이버 쇼핑커넥트 등록부(브랜드커넥트에서 발급한 링크)를 찾아본다.
* 짧은 요청(2026-11-02~)도 상품어만 검색하고, 그 말(또는 같은 부류의 말)과 겹치는 상품만 보여 준다.
"""
from __future__ import annotations

from app.services.chat.service import ChatService, relevant, shopping_terms
from app.services.recipe_chat.service import RecipeChat
from tests.services.chat.conftest import FakeShopping

SENTENCE = "휘태커스초콜릿 중에 너무 달지 않고 아이랑 같이 먹기 좋은 거 추천해 줘"
JUNK = [{"product_name": n, "price": 9000, "product_url": "https://www.coupang.com/x", "platform_name": "coupang"}
        for n in ("올덴 화롯불 특대형 대용량 핫팩 150g, 20개", "위칙 소독 섬유유연제 본품, 2.3L", "레노버 아이디어패드 슬림 3")]
GOOD = [{"product_name": "휘태커스 다크 초콜릿 72% 250g", "price": 8900, "product_url": "https://www.coupang.com/w",
         "platform_name": "coupang"}]


def md(res):
    return "\n".join(b["data"].get("md", "") for b in res["blocks"] if b["type"] in ("text", "notice"))


def test_a_sentence_is_searched_by_its_product_word():
    assert shopping_terms(SENTENCE) == ("휘태커스초콜릿", ["휘태커스초콜릿"])
    assert shopping_terms("사과 추천해줘") == ("사과", ["사과"])          # 2026-11-02: 짧은 요청도 상품어만 검색·관련성 확인
    assert shopping_terms("사과를 추천해 줘") == ("사과", ["사과"])
    assert shopping_terms("두바이 쫀득쿠키 추천해줘")[0] == "두바이 쫀득쿠키"
    assert shopping_terms("빼빼로데이에 회사 동료 20명한테 돌릴 과자 선물 추천해 줘")[0] == "빼빼로데이"
    word = shopping_terms("빼빼로데이에 회사 동료 20명한테 돌릴 과자 선물 추천해 줘", lambda t: {"keyword": "과자"})
    assert word == ("과자", ["과자"])
    assert shopping_terms(SENTENCE.replace("휘태커스초콜릿 중에", "회사에서"), lambda t: {"keyword": "노트북"})[0] != "노트북"


def test_unrelated_products_are_never_recommended(sqlite_db, monkeypatch):
    monkeypatch.delenv("NAVER_CONNECT_REGISTRY_CSV", raising=False)
    shop = FakeShopping(items=JUNK)
    svc = ChatService(sqlite_db, shopping=shop, recipe_chat=RecipeChat(statement_factory=str))
    res = svc.handle(None, message=SENTENCE)
    assert shop.calls[0][0] == "휘태커스초콜릿"
    assert not any(b["type"] == "product_list" for b in res["blocks"])
    assert "쿠팡에서 **휘태커스초콜릿** 관련 상품을 찾지 못했어요. 관련 없는 상품은 보여 드리지 않았어요." in md(res)
    assert "네이버 쇼핑커넥트(브랜드커넥트)에 등록한 **휘태커스초콜릿** 링크도 아직 없어요." in md(res)


def test_related_products_are_kept(sqlite_db):
    svc = ChatService(sqlite_db, shopping=FakeShopping(items=JUNK + GOOD), recipe_chat=RecipeChat(statement_factory=str))
    res = svc.handle(None, message=SENTENCE)
    items = next(b for b in res["blocks"] if b["type"] == "product_list")["data"]["items"]
    assert [i["title"] for i in items] == ["휘태커스 다크 초콜릿 72% 250g"]


def test_registered_shopping_connect_links_are_shown_when_coupang_has_none(sqlite_db, tmp_path, monkeypatch):
    reg = tmp_path / "naver_connect_links.csv"
    reg.write_text("키워드,상품명,스토어명,판매가,쇼핑커넥트 링크,수수료율(%),발급일,링크 확인일,사용처(블로그/사이트),메모\n"
                   "휘태커스초콜릿,휘태커스 밀크 초콜릿 250g,초콜릿상점,9500,https://naver.me/abc,3,2026-10-31,2026-10-31,사이트,\n"
                   "과메기,구룡포 과메기,바다,20000,,3,,,,\n", encoding="utf-8-sig")
    monkeypatch.setenv("NAVER_CONNECT_REGISTRY_CSV", str(reg))
    svc = ChatService(sqlite_db, shopping=FakeShopping(items=JUNK), recipe_chat=RecipeChat(statement_factory=str))
    res = svc.handle(None, message=SENTENCE)
    items = next(b for b in res["blocks"] if b["type"] == "product_list")["data"]["items"]
    assert [(i["mall"], i["title"], i["url"], i["price"]) for i in items] == [
        ("네이버 (쇼핑커넥트)", "휘태커스 밀크 초콜릿 250g", "https://naver.me/abc", 9500)]
    assert "네이버 쇼핑커넥트(브랜드커넥트)에서 발급해 등록해 둔 링크예요." in md(res)
    assert all(i["affiliate"] is True and i["affiliate_program"] == "네이버 쇼핑커넥트" for i in items)
    assert items[0]["source"] == "초콜릿상점"
    assert "수수료" in md(res) and "무료 운영" in md(res)


def test_relevance_is_about_shared_words():
    assert relevant("Whittaker's 휘태커스 밀크 초콜릿", ["휘태커스초콜릿"])
    assert not relevant("올덴 화롯불 특대형 대용량 핫팩", ["휘태커스초콜릿"])


def test_connect_links_are_listed_separately_next_to_coupang_results(sqlite_db, tmp_path, monkeypatch):
    """2026-11-02: 쿠팡 결과가 있어도 쇼핑커넥트 등록 상품을 별도 목록으로 보여 주고, 쿠팡 후보의 순서는 바꾸지 않는다."""
    reg = tmp_path / "naver_connect_links.csv"
    reg.write_text("상품명,스토어명,판매가,쇼핑커넥트 링크,키워드,링크 확인일\n"
                   "휘태커스 밀크 초콜릿 250g,초콜릿상점,9500,https://naver.me/abc,휘태커스초콜릿,2026.11.2\n",
                   encoding="utf-8-sig")
    monkeypatch.setenv("NAVER_CONNECT_REGISTRY_CSV", str(reg))
    svc = ChatService(sqlite_db, shopping=FakeShopping(items=JUNK + GOOD), recipe_chat=RecipeChat(statement_factory=str))
    res = svc.handle(None, message=SENTENCE)
    lists = [b["data"] for b in res["blocks"] if b["type"] == "product_list"]
    assert [i["title"] for i in lists[0]["items"]] == ["휘태커스 다크 초콜릿 72% 250g"]
    connect = next(d for d in lists if d.get("title", "").startswith("네이버 쇼핑커넥트 등록 상품"))
    assert [(i["title"], i["url"], i["affiliate"]) for i in connect["items"]] == [
        ("휘태커스 밀크 초콜릿 250g", "https://naver.me/abc", True)]
    assert "수수료" in connect["note"] and connect["items"][0]["rank"] == 2


def test_short_requests_also_find_registered_connect_links(sqlite_db, tmp_path, monkeypatch):
    reg = tmp_path / "naver_connect_links.csv"
    reg.write_text("상품명,스토어명,판매가,쇼핑커넥트 링크,키워드\n영주사과 홍로 2kg,햇살품은사과,22900,https://naver.me/s,사과 홍로\n",
                   encoding="utf-8-sig")
    monkeypatch.setenv("NAVER_CONNECT_REGISTRY_CSV", str(reg))
    apple = [{"product_name": "경북 부사 사과 3kg", "price": 19900, "product_url": "https://www.coupang.com/a",
              "platform_name": "coupang"}]
    svc = ChatService(sqlite_db, shopping=FakeShopping(items=apple), recipe_chat=RecipeChat(statement_factory=str))
    res = svc.handle(None, message="사과 추천해줘")
    titles = [i["title"] for b in res["blocks"] if b["type"] == "product_list" for i in b["data"]["items"]]
    assert "영주사과 홍로 2kg" in titles and "경북 부사 사과 3kg" in titles


def test_alcohol_requests_never_get_connect_links(sqlite_db, tmp_path, monkeypatch):
    """어필리에이트 운영정책 1장: 주류 관련 콘텐츠는 활동 제한 채널 — 술 질문에는 쇼핑커넥트 목록을 붙이지 않는다."""
    from app.services.chat.service import is_alcohol_request
    assert is_alcohol_request("와인 추천해줘") and is_alcohol_request("막걸리랑 어울리는 전") and is_alcohol_request("술안주 추천")
    assert not is_alcohol_request("맛술 대신 쓸 것") and not is_alcohol_request("사과 추천해줘") and not is_alcohol_request("술빵 만들기")
    reg = tmp_path / "naver_connect_links.csv"
    reg.write_text("상품명,스토어명,판매가,쇼핑커넥트 링크,키워드\n하루견과 믹스,넛츠피아,29900,https://naver.me/n,견과 안주\n",
                   encoding="utf-8-sig")
    monkeypatch.setenv("NAVER_CONNECT_REGISTRY_CSV", str(reg))
    nuts = [{"product_name": "하루견과 믹스 20봉", "price": 19900, "product_url": "https://www.coupang.com/n", "platform_name": "coupang"}]
    svc = ChatService(sqlite_db, shopping=FakeShopping(items=nuts), recipe_chat=RecipeChat(statement_factory=str))
    res = svc.handle(None, message="맥주 안주 견과 추천해줘")
    assert not any((b["data"].get("title") or "").startswith("네이버 쇼핑커넥트") for b in res["blocks"] if b["type"] == "product_list")
    assert "쇼핑커넥트" not in md(res)


def test_connect_cards_open_the_issued_link_directly(sqlite_db, tmp_path, monkeypatch):
    reg = tmp_path / "naver_connect_links.csv"
    reg.write_text("상품명,스토어명,판매가,쇼핑커넥트 링크,키워드\n영주사과 홍로 2kg,햇살품은사과,22900,https://naver.me/s,사과\n",
                   encoding="utf-8-sig")
    monkeypatch.setenv("NAVER_CONNECT_REGISTRY_CSV", str(reg))
    svc = ChatService(sqlite_db, shopping=FakeShopping(items=[]), recipe_chat=RecipeChat(statement_factory=str))
    res = svc.handle(None, message="사과 추천해줘")
    card = next(i for b in res["blocks"] if b["type"] == "product_list" for i in b["data"]["items"])
    assert card["direct"] is True and card["url"] == "https://naver.me/s"


def test_short_requests_drop_unrelated_products_but_keep_the_same_kind():
    """2026-11-02 실제 화면: '사과를 추천해 줘'에 '제이커스 종이소녀상만들기'가 섞였다."""
    assert not relevant("제이커스 종이소녀상만들기", ["사과"])
    assert relevant("아삭달콤 과즙 가득 제철 햇사과 10kg", ["사과"])
    assert relevant("곰곰 호주산 앞다리 샤브샤브용 (냉장)", ["소고기"])      # 부류 이름 → 같은 부류
    assert relevant("나주배 7.5kg", ["배"]) and not relevant("무료배송 사과 3kg", ["배"])
    assert relevant("제주 노지 감귤 3kg", ["귤"])


def test_short_request_shows_only_related_products(sqlite_db):
    items = [{"product_name": n, "price": p, "product_url": f"https://www.coupang.com/{i}", "platform_name": "coupang"}
             for i, (n, p) in enumerate([("아삭달콤 햇사과 10kg", 33900), ("제이커스 종이소녀상만들기", 2200)])]
    shop = FakeShopping(items=items)
    res = ChatService(sqlite_db, shopping=shop, recipe_chat=RecipeChat(statement_factory=str)).handle(None, message="사과를 추천해 줘")
    titles = [i["title"] for b in res["blocks"] if b["type"] == "product_list" for i in b["data"]["items"]]
    assert shop.calls[0][0] == "사과" and titles == ["아삭달콤 햇사과 10kg"]


def test_beef_request_does_not_take_pork_with_the_same_cut_name():
    """'목심'·'앞다리'는 소·돼지 모두에 있다 — '소고기'에 '한돈 목살'이, '돼지고기'에 '한우 앞다리'가 섞이지 않게."""
    assert not relevant("한돈 목살 구이용 500g", ["소고기"]) and not relevant("돼지 목심", ["소고기"])
    assert relevant("한우 앞다리 불고기용", ["소고기"]) and not relevant("한우 앞다리 불고기용", ["돼지고기"])
    assert relevant("한돈 앞다리 수육용", ["돼지고기"])
