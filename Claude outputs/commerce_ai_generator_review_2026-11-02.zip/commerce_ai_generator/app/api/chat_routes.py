"""Conversation API used by the React ui_ux front end.

    POST /api/chat           {session_id, message | answers | chip} → {session_id, stage, blocks}
    GET  /api/recipe/easy    ?recipe_id=&key=  → 쉽게 보기 / AI image when ready (read-only polling)
    GET  /api/recipe/image   ?recipe_id=&v=    → stored AI dish image (read-only)
    GET  /go/{sid}/{rank}    click log + redirect to a product shown in that session
    GET  /go/{sid}/k/{key}   same, by the card's key (cards of earlier questions keep their own product)
    GET  /go/s/{owner}/{key} same, for a product in the 관심 상품 보관함
    GET  /api/chat/saved     ?owner=&session_id= → 관심 상품 + 최근 본 상품
    POST /api/chat/saved     {owner, session_id, key, on} → ♡ 담기/빼기 (서버가 보여 준 후보에서만 복사)

No secret is sent to the browser: the DeepSeek key stays in the server
environment and is only read by app.services.nlu.LLMClient.
"""
from __future__ import annotations

import logging
import os
import threading

from fastapi import APIRouter, Depends, Query
from fastapi.responses import RedirectResponse, Response
from pydantic import BaseModel, Field

from app.services.chat.service import ChatService, engine_db

log = logging.getLogger(__name__)
router = APIRouter(tags=["chat"])

_service: ChatService | None = None
_lock = threading.Lock()


class ChatIn(BaseModel):
    session_id: str | None = Field(None, max_length=64)
    message: str | None = Field(None, max_length=500)
    answers: dict[str, str] | None = None
    chip: str | None = Field(None, max_length=200)
    # 2026-11-01: 관심 상품 보관함 id (브라우저별, '새 대화'를 눌러도 유지)
    owner: str | None = Field(None, max_length=64)


class ClickIn(BaseModel):
    session_id: str = Field(..., max_length=64)
    rank: int = Field(..., ge=1, le=200)
    url: str = Field(..., max_length=2000)


class SavedIn(BaseModel):
    owner: str = Field(..., max_length=64)
    session_id: str | None = Field(None, max_length=64)
    key: str = Field(..., max_length=32)
    on: bool = True


def _deepseek_ready() -> bool:
    return bool((os.getenv("DEEPSEEK_API_KEY") or "").strip() and (os.getenv("DEEPSEEK_MODEL") or "").strip())


def build_default_service() -> ChatService:
    from app.services.nlu.food_nlu import load_food_nlu
    from app.services.recipe_chat.service import RecipeChat
    from app.services.recipe_session.direct_stock_chat import interpret

    from app.services.recipe_chat import ai_image, easy_view
    from app.services.recipe_chat.catalog_store import CatalogProvider

    from app.services.recipe_chat import servings as servings_mod
    from app.services.recipe_chat import ai_recipe, discover, supplement

    ready = _deepseek_ready()
    db = engine_db()
    recipe = RecipeChat(stock_interpreter=interpret if ready else None,
                        # unclear servings messages only; validated before the state changes
                        servings_interpreter=servings_mod.llm_interpreter() if ready else None,
                        catalog_provider=CatalogProvider.from_env(),
                        easy_views=easy_view.from_env(),
                        ai_images=ai_image.from_env(),
                        # missing core step (원문 아님 · AI) — same key rule, validated before it is shown
                        supplements=supplement.from_env(),
                        # trend / new dish / link: NAVER search (server keys) + DeepSeek reading, validated
                        discovery=discover.from_env(),
                        # 'AI 제안 레시피' for dishes outside the catalogue (labelled, validated, stored once per dish)
                        ai_recipes=ai_recipe.from_env(db=db, statement_factory=db.sql),
                        consultant=None)
    # 2026-11-01: recipe consultation ('참치 샐러드 식감을 살리는 재료') — DeepSeek candidates, catalogue + blog evidence
    from app.services.recipe_chat import consult
    from app.services.recipe_chat.catalog_store import requested_kind

    if ready:
        from app.services.nlu.llm_client import LLMClient

        reader = LLMClient(consult.PROMPT, provider="deepseek", timeout=60.0)
        recipe.consultant = consult.Consultant(lambda text: reader.chat_json(text, temperature=0.2),
                                               recipe.resolver.catalog, search=getattr(recipe.discovery, "provider", None),
                                               kind_of=requested_kind)
    keyword_extractor = None
    if ready:      # long shopping sentences → their product word (validated: it must be in the sentence)
        from app.services.chat.service import SHOP_KEYWORD_PROMPT
        from app.services.nlu.llm_client import LLMClient

        client = LLMClient(SHOP_KEYWORD_PROMPT, provider="deepseek")
        keyword_extractor = lambda text: client.chat_json(text, temperature=0)  # noqa: E731
    return ChatService(db, nlu_loader=load_food_nlu, recipe_chat=recipe, keyword_extractor=keyword_extractor)


def get_chat_service() -> ChatService:
    global _service
    with _lock:
        if _service is None:
            _service = build_default_service()
        return _service


_DEV = {"mtime": None, "on": None}


def dev_trace_on() -> bool:
    """CHAT_DEV_TRACE read from the repository .env again whenever the file changes (load_dotenv copied the start-up
    value into the environment, so the file wins) — switching development mode off needs no restart (2026-10-30).
    Without the key in .env, the process environment decides."""
    from pathlib import Path

    path = Path(__file__).resolve().parents[2] / ".env"
    try:
        mtime = path.stat().st_mtime
    except OSError:
        mtime = None
    if mtime is not None and mtime != _DEV["mtime"]:
        from dotenv import dotenv_values

        _DEV.update(mtime=mtime, on=dotenv_values(path).get("CHAT_DEV_TRACE"))
    value = _DEV["on"] if mtime is not None and _DEV["on"] is not None else os.environ.get("CHAT_DEV_TRACE")
    return (value or "").strip() == "1"


def public(response: dict) -> dict:
    """Verification details (search terms, API addresses, call log) leave the server only in development mode
    (CHAT_DEV_TRACE=1).  Customer responses never carry them."""
    if dev_trace_on():
        return response
    blocks = [dict(b, data={k: v for k, v in b["data"].items() if k != "trace"})
              if isinstance(b.get("data"), dict) else b for b in response.get("blocks") or []]
    return {**response, "blocks": blocks}


@router.post("/api/chat")
def chat(body: ChatIn, service: ChatService = Depends(get_chat_service)):
    return public(service.handle(body.session_id, message=body.message, answers=body.answers, chip=body.chip,
                                 owner=body.owner))


@router.get("/api/chat/saved")
def saved_view(owner: str | None = Query(None, max_length=64), session_id: str | None = Query(None, max_length=64),
               service: ChatService = Depends(get_chat_service)):
    return service.saved_view(owner, session_id)


@router.post("/api/chat/saved")
def saved_set(body: SavedIn, service: ChatService = Depends(get_chat_service)):
    return service.set_saved(body.owner, body.session_id, body.key, body.on)


@router.get("/api/trends/surge")
def trends_surge():
    """'지금 뜨는 식품' (customer tab): today's surge report in short — no search terms, API names or call logs."""
    from app.services.trends import surge

    return surge.public_view(surge.load())


@router.get("/api/recipe/easy")
def recipe_easy(recipe_id: str = Query(..., max_length=64), key: str | None = Query(None, max_length=64),
                service: ChatService = Depends(get_chat_service)):
    return service.recipe_easy(recipe_id, key)


@router.get("/api/recipe/image")
def recipe_image(recipe_id: str = Query(..., max_length=64), v: str = Query(..., max_length=64),
                 service: ChatService = Depends(get_chat_service)):
    found = service.recipe_image(recipe_id, v)
    if found is None:
        return Response(status_code=404)
    mime, data = found
    # the URL carries the source version, so the bytes never change for it
    return Response(content=data, media_type=mime, headers={"Cache-Control": "public, max-age=31536000, immutable"})


@router.post("/api/click", status_code=204)
def click(body: ClickIn, service: ChatService = Depends(get_chat_service)):
    """바로 이동 링크(네이버 쇼핑커넥트)의 클릭 기록 (2026-11-02).

    링크는 브라우저가 발급 주소 그대로 연다 — 이 호출은 이동과 무관한 기록용(sendBeacon)이다.
    직전에 보여 준 상품의 링크와 같을 때만 기록하고, 응답은 항상 204 (기록 여부를 알려 주지 않음)."""
    item = service.shown_item(body.session_id, body.rank)
    if item and item.get("url") == body.url:
        try:
            from app.services.analytics_logger import log_product_click

            log_product_click(session_id=body.session_id, query="chat", product={
                "product_url": item["url"], "product_name": item.get("title"), "mall_name": item.get("mall"),
                "rank": body.rank, "selected_section": "chat_direct", "recommendation_mode": "ranking"})
        except Exception:  # noqa: BLE001 — 기록 실패가 화면에 영향을 주지 않는다
            log.warning("direct click log failed")
    return Response(status_code=204)


@router.get("/go/{sid}/k/{key}")
def go_key(sid: str, key: str, service: ChatService = Depends(get_chat_service)):
    return _redirect(sid, service.resolve_go_key(sid, key))


@router.get("/go/s/{owner}/{key}")
def go_saved(owner: str, key: str, service: ChatService = Depends(get_chat_service)):
    return _redirect(owner, service.resolve_saved_go(owner, key), section="saved")


@router.get("/go/{sid}/{rank}")
def go(sid: str, rank: int, service: ChatService = Depends(get_chat_service)):
    return _redirect(sid, service.resolve_go(sid, rank))


def _redirect(sid: str, url: str | None, section: str = "chat"):
    if url is None:
        return RedirectResponse("/")
    try:
        from app.services.analytics_logger import log_product_click

        log_product_click(session_id=sid, query="chat", product={
            "product_url": url, "selected_section": section, "recommendation_mode": "ranking"})
    except Exception:  # noqa: BLE001 — logging must not block the redirect
        log.warning("click log failed")
    return RedirectResponse(url)
