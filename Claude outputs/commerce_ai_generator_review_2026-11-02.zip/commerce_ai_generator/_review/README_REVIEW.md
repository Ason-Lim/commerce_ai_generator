# commerce_ai_generator 검토용 코드 패키지 (2026-11-02)

GPT 검토 문서 「commerce_core_stage0-2 … 검토·OCR 상세 보완」 H.1~H.3 요청에 대한 제출물.
기준 커밋: `_review/git_head.txt` (작업 트리에는 커밋되지 않은 변경이 많음 → `_review/git_status_at_packaging.txt`).

## 1. 이번 작업(0~2단계)의 변경 범위
- **기존 파일 수정 없음. 새 파일 9개만 추가, 커밋 안 함.** 전체 diff: `_review/new_files.patch`
  - app/domain/__init__.py, app/domain/commerce/{__init__,models,requests,policies}.py
  - app/services/commerce/{__init__,search,recipes}.py
  - tests/services/chat/test_commerce_contract.py
- 이 wrapper 들은 아직 어디에서도 호출되지 않는다 (REST·MCP 연결 전).

## 2. 실제 호출 위치 (현재 소스 기준 file:line)
| 단계 | 위치 |
|---|---|
| POST /api/chat | app/api/chat_routes.py `chat()` → `ChatService.handle` |
| 쇼핑 턴 | app/services/chat/service.py:503 `_shopping_turn` |
| 상품 공급 | service.py:75 `default_shopping` → app/main.py:336 `natural_language_recommendations` → app/services/recommendation_pipeline.py:299 `run_recommendation_pipeline` (실패 시 main.py 의 DB fallback) |
| 카드 변환 | service.py:83 `item_to_card`, app/services/chat/explain.py:98 `enrich`, :63 `card_key` |
| 최종 순위·역할 | explain.py:125 `choose` — 호출 3곳: service.py:535(쇼핑 턴), :370(예산 답변 턴), :340(관심 상품 비교) |
| 시세 참고 | service.py:396 → app/services/public_price/kamis.py:316 `annotate` (choose 이후, 순위 무관) |
| 업체 제공 | app/services/partners/feed.py:78 `offers`, :124 `note_line` |
| 쇼핑커넥트 | service.py:721 `connect_links`, :708 `is_alcohol_request` |
| 레시피 | app/services/recipe_chat/catalog.py:52 `RecipeResolver.get`, :133 `find` |

**wrapper 가 다루지 않는 경로**: 예산 답변 턴(:370)·관심 상품 비교(:340)는 저장된 카드로 `choose` 를 다시 부른다. 3단계 REST 교체 때 함께 다뤄야 한다.

## 3. 변경 전/후 테스트 (같은 환경)
- 환경: 사용자 맥 위 Linux VM, Python 3.10.12, requirements.txt 설치. **맥 운영 환경(.venv, Python 3.14) 실행 아님.**
- 방법: 저장소를 VM 안 별도 위치로 복사(백업 폴더·node_modules 제외, data 는 링크) → 새 파일 없이 실행(before) → 새 파일 9개만 추가해 다시 실행(after).
- before: `11 failed, 5010 passed, 5 skipped` (`_review/baseline_before.txt`)
- after: `11 failed, 5030 passed, 5 skipped` (`_review/baseline_after.txt`) — **실패 목록 동일**, 늘어난 20개 = 계약 테스트
- 계약 테스트 상세: `_review/contract_tests_verbose.txt`
- 11개 중 4개(tests/admin)는 복사 때 백업 폴더를 뺀 영향, 원래 폴더에서는 통과. 원래 폴더 실행에서는 test_surge 1개가 실제 var/blog_drafts 파일 삭제를 시도하다 VM 권한으로 막혀 실패 → **이 테스트는 맥에서 돌리면 실제 파일을 지울 수 있으므로 임시 디렉터리 격리 필요.**
- 계약 테스트 유효성: search.py 에서 picks 순서를 일부러 뒤집으면 5개 실패하는 것을 확인 후 원복.

## 4. OCR·상세페이지 코드 (읽기 전용 조사, H.2)
- `commerce_ai_local_ocr/` (1,220줄, 이 패키지에 포함): Tesseract 를 subprocess 로 부르는 독립 CLI (`python -m commerce_ai_local_ocr --input …`), 영역 검출 regions.py(PIL), 선택적 OpenAI Responses 검토 review.py(JSON schema 검증, 이미지 base64 전송), 옵션·수량 해석 options.py / variant_quantity.py / offer_rows.py / inline_offer.py(뒤 4개는 git 미추적 새 파일).
- **app/·scripts/ 의 어떤 파이썬 파일도 이 패키지를 import 하지 않는다** (grep 기준) → /api/chat·추천 파이프라인과 연결되지 않은 오프라인 도구. tests/ 에 OCR 테스트 없음(파일명·내용 grep 기준).
- 결과 저장: 기본 `ocr_results/<시각>/` 폴더(패키지에서 제외). 증거 저장소·충돌 처리·비용 계측 코드는 이번 검색 범위에서 찾지 못함 — 전체 미존재로 일반화하지 않음.
- 상세페이지 수집기(쿠팡·스마트스토어·컬리 페이지)는 2026-11-02 결정으로 보관(archive)·미사용. **OCR 대상 상세페이지는 수집 허용이 기록된 출처(partners/ 허락 기록부의 업체 제공 이미지 등)로 한정해야 하며, 쿠팡·네이버 상품 페이지를 새로 긁는 설계로 읽혀서는 안 된다.**

## 5. 평점·후기 추적 (A표 rating 항목)
- 정식 경로 어댑터(recommendation/popularity_adapter.py, market_adapter.py, trust_adapter.py)는 docstring 과 코드에서 raw rating/review_count 를 계산에서 명시적으로 제외.
- 미추적: ① 상위 `popularity_score` 가 어디서 어떻게 만들어지는지, ② 파이프라인 실패 시 main.py DB fallback 과 recommendation/score_engine.py(rating 참조 23곳)가 순서에 영향을 주는지.
- `explain.choose` 의 남은 자리(alt)는 **입력 순서**를 따르므로, 상위 순서가 평점의 영향을 받으면 화면 순서에도 간접 반영될 수 있다 → 새 Evidence 표시만으로 기존 소비가 차단됐다고 말할 수 없다는 지적은 맞다.

## 6. GPT 검토(A~H)에 대한 응답 요약
| 항목 | 응답 |
|---|---|
| 기존 실패 8개 → 전/후 동일 환경 | 위 3절로 수행. 같은 환경에서 실패 집합 동일. 맥 환경은 미실행 |
| final_score ≠ 표시 rank | 동의. 모델에서 `score.rank`(choose 결과)와 `engine_score`(상위 값, 있을 때만)를 분리해 둠 |
| commerce.v1·상태 6종 | 잠정안 동의. 기존 versioned envelope(READY/EMPTY/HELD) 위치는 이번 조사에서 아직 확인 못 함 → 위치를 알려 주면 대조표 작성 |
| key/pid canonical 아님 | 동의. models.py 주석에 명시 |
| usable_for_score bool 부족 | 동의. 다음 단계에서 용도별 판정(display/filter/price_compare/score) + policy_version 으로 확장 제안 |
| 판매처 장애 partial | 현재 쇼핑 공급자는 1개. 공급자 실패 + 등록부·업체 결과가 있으면 이미 `partial` 반환, 없으면 `error`. 여러 공급자 구분은 공급자가 늘 때 |
| OCR 미확인 | 4절로 확인: 존재하지만 미연결 오프라인 도구 |
| OCR 설계 B~G | 방향 동의. 단 수집 대상은 허락된 출처로 한정(4절), 검색 후보마다 실행 금지·비용 제한 동의 |

## 7. 제외한 것
.env 와 모든 .env.* 백업(실키 포함), data/(1.2GB, DB·수집 데이터), var/, 각종 *_backups 폴더, ocr_results/, frontend/node_modules·dist, __pycache__, zip 번들, 거버넌스 문서 묶음, docs/, B2B 증빙 데이터(app/admin/b2b/data/*.json 7.5MB, company_profiles.json — 기업 정보). 비밀키 패턴(sk-, AKIA, DB URL 비밀번호 등) 검색 결과 0건. `.env.example` 은 자리표시자만 있어 포함.
→ 일부 테스트(B2B·NTS·레시피 카탈로그 등 data/ 필요)는 이 패키지만으로는 실행되지 않는다.
