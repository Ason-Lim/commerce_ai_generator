# commerce_ai p35·p36·p37 검토 패키지 (2026-11-03) — MCP 실제 호출 보완 · 레시피 DB · 업체 관련성 · 확인 기록표

코드는 맥 원본 현재 파일 사본. 커밋하지 않음. 비밀키·.env·data/(템플릿 1개 제외) 미포함.

## 실행 환경
| 로그 | 어디서 |
|---|---|
| test_logs/p3x_linux_copy_full.txt | 맥 저장소의 Linux VM 사본, Python 3.10 — p35 5,139 / p36 5,164 / p37 5,175 passed, 실패 7개 목록 동일 |
| test_logs/p37_mac_folder_linux_python_*.txt | 맥 원본 폴더, Linux Python 3.10 — MCP·확인 기록표·관련성·OCR 53 passed |
| 맥 .venv | p34 까지 chat·partners 422 passed (사용자 실행). p35~p37 은 아직 |
| mcp_actual/ | 실제 MCP 서버 호출 요약 (p34·p36 서버) |

## p35 (diffs/p35.diff) — 1차 실제 호출에서 찾은 문제
- 빈 검색어: 판매처 호출 없이 bad_request.
- 제휴 링크 보류 중 제휴 이미지 주소도 비움.
- 미리 보기 예시 데이터: (p35) 서버 환경 강제 + 경고 문구 검사 → **p37 에서 교체**.
- tests/mcp_adapter/conftest.py: 실제 .env·업체 데이터와 격리.

## p36 (diffs/p36.diff)
- MCP 서버 `_bind_engine()`: 웹(main.py lifespan)·Streamlit 과 같이 DB 엔진 등록 → 레시피 카탈로그 복구(사용자 진단 EngineProviderUnboundError). 실패해도 도구는 동작(stderr 알림).
- 업체 상품 관련성 `search.partner_match` (사용자 결정): 상품 낱말 모두 필요.
- 확인 기록표 `app/services/partners/verification.py` (사용자 결정: 적힌 값만 '검증됨'), 템플릿 `data/partners/verified_values_template.csv`. 업체 상품 검색 근거·OCR 근거에 연결. 점수는 열리지 않음.

## p37 (diffs/p37.diff) — GPT 검토(16:45)
1. **원산지·보관 상태는 조건**: 국산/국내산·수입/수입산·냉장·냉동은 꾸밈 낱말에서 빼고, 업체 상품명에 같은 뜻의 표기가 있어야 통과(없으면 확인 불가로 제외). 용도·포장·때(…용, 세트, 명절 등)는 여전히 필수 아님. 테스트 7개 사례.
2. **확인 기록표 단위**: 업체·대상·항목·값·**단위**가 모두 같아야 verified (빈 단위는 빈 단위끼리만). 단위가 다른 기록뿐이면 그대로. **유효한 기록끼리 값이 다르면** 현재 값이 그중 하나와 같아도 conflict. 만료된 기록은 셈에 넣지 않음.
3. **미리 보기 정책을 호출별·명시 값으로**: `feed.offers(preview=...)` · `collect/search_products(allow_preview=...)` 추가(None = 기존 PARTNER_PREVIEW 설정, 웹 그대로). MCP 도구는 매 호출 `allow_preview=False`. 결과 `Provenance.preview_data`(명시 bool) — MCP 는 경고 문구가 아니라 이 값이 참이면 통째로 held(fail closed). p35 의 서버 환경 변수 강제는 제거(프로세스 환경을 바꾸지 않음, 테스트로 고정).
4. **OCR 점수 차단 유지**: 확인 기록으로 verified 가 돼도 OCR·html 은 score=block (test_verification_log::test_ocr_option_value_is_verified_by_image_hash_and_option).
5. **쿠팡 ', 200g, 3개'**: GPT 권고대로 자동 계산하지 않음. 현재처럼 총중량·100g당 비교 보류, 근거 raw_text 에 '200g, 3개' 구성 후보 보존(mcp_actual 2차 참고). 코드 변경 없음.

## 남은 일
- p37 반영 후 MCP 서버 재시작 → 실제 응답 재확인 (preview_data=false, 조건 낱말)
- 맥 .venv 에서 p35~p37 테스트
- 가격·구성 연결 확인 방법(API 옵션·수량 필드 또는 확인 기록)
