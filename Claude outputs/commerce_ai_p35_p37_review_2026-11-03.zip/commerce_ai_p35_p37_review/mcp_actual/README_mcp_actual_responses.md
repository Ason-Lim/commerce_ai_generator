# 실제 MCP 호출 결과 (Claude 클라이언트 → 사용자 맥 로컬 MCP 서버 commerce-ai-food, 실제 판매처 API)

원 응답(JSON)은 대화 안에서 받은 것을 클로드가 요약해 옮겼다 — 이 파일은 원 응답 사본이 아니다.
p37 반영 후 재시작한 서버의 응답은 아직 없다 (사용자 재시작 후 다시 호출 예정).

## 1차 (2026-11-03 16:0x, p34 코드 서버)
| 호출 | 결과 요약 |
|---|---|
| food_search_products('5만원 이하 한우 등심', 5) | status=ok, schema commerce.v1, recommendation_path=canonical_provider. 11개 중 '(예시)' 업체 상품 7개(한우이츠·미트프렌즈·현덕축산), 1위 '가성비' = '(예시) 한우 1+등급 양지 국거리 500g'. warnings 에 미리 보기 경고·제휴 링크 보류. 쿠팡 항목 product_url=null, image_url 은 ads-partners.coupang.com 주소 그대로 |
| food_search_products('와인 추천', 50) | ok, 쿠킹 와인 1건, connect 섹션 없음, limit 은 10 으로 제한 |
| food_search_products(' ') | status=empty, provenance.recommendation_path=canonical_provider (빈 검색어로 판매처 호출됨) |
| food_get_recipe(dish_name='크림파스타') | ok, EPIS:467, citation '원문을 참고해 정리, 원문 그대로가 아님' |
| food_get_recipe(dish_name='파스타') | needs_followup, 후보 1개(EPIS:467) |
| food_get_recipe() / ('NOPE:999') | error bad_request / empty |

## 2차 (2026-11-03 16:39, p36 코드 서버 — Claude 재시작 후)
| 호출 | 결과 요약 |
|---|---|
| food_get_recipe(dish_name='파스타') | needs_followup, 후보 4개: epis-318 버섯파스타 · EPIS:467 크림소스파스타 · fs-496 단호박크림파스타 · fs-660 삼색채소 냉파스타 |
| food_search_products('5만원 이하 한우 등심', 5) | ok, 5개 모두 쿠팡·모두 등심, '(예시)' 없음, product_url·image_url 모두 null, warnings 에 '제휴(수수료) 링크와 제휴 이미지 주소는 …', 예산 안/밖 사유, upstream_rank 1~5, fallback_used=false. '…등심 구이용 (냉장), 200g, 3개' → weight_g null, 근거 status=conflict raw_text '200g, 3개'(총중량 불명확), per_unit 24,390원 |
| food_search_products('  ') | status=error, bad_request '검색할 상품이나 문장을 적어 주세요.', provenance.recommendation_path=null (판매처 호출 없음) |

주의: 2차의 '예시 없음'은 p36 서버에서 PARTNER_PREVIEW=0 환경 강제 + 경고 문구 검사로 얻은 결과다. p37 은 이를 호출별 정책(allow_preview=False)과 명시 값(provenance.preview_data)으로 바꿨다 — 그 검증은 코드·테스트(`test_mcp_call_excludes_preview_by_its_own_policy`, `test_mcp_fails_closed_on_the_explicit_preview_flag`)로 했고, 실제 서버 응답은 재시작 후 확인 예정.
