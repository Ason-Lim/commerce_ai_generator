"""상품명 중량 해석 (2026-11-03 p32): 옵션 목록은 쓰지 않고, 명시된 곱하기만 계산한다."""
from __future__ import annotations

import pytest

from app.domain.commerce.requests import SearchRequest
from app.services.chat import explain
from app.services.chat.explain import parse_units, parse_weight
from app.services.commerce.search import search_products
from tests.services.chat.conftest import FakeShopping


@pytest.mark.parametrize("title, weight, kind, formula", [
    ("한우 등심 300g", 300, "single", None),
    ("고구마 3kg 꿀고구마 3kg", 3000, "single", None),                   # 같은 값 반복은 하나
    ("국산 삼겹살 500g x 2팩", 1000, "multiplied", "500g×2"),
    ("국산 삼겹살 500g×2팩", 1000, "multiplied", "500g×2"),
    ("귤 2.5kg X 2박스", 5000, "multiplied", "2.5kg×2"),
    ("삼겹살 500g x 2 총 1kg", 1000, "multiplied", "500g×2"),             # 곱한 값과 총량이 같으면 그 값
    ("사과 경북 청송 안동 가정용 못난이 부사 5kg 10kg", None, "ambiguous", None),
    ("사과유명한곳 사과10키로 햇 부사 선물용 5kg 3kg 충주", None, "ambiguous", None),
    ("삼겹살 500g x 2 총 1.2kg", None, "ambiguous", None),               # 곱한 값과 총량이 다르면 모름
    ("닭가슴살 100g 10팩", None, "count_unclear", None),                 # p33: 개당·전체 불명 → 쓰지 않음
    ("삼겹살 500g 1팩", 500, "single", None),                             # 1개면 그대로
    ("닭가슴살 1kg (100g x 10팩)", 1000, "multiplied", "100g×10"),       # 곱한 값과 총량이 같음
    ("우유 900ml x 2개", None, "none", None),
])
def test_parse_weight(title, weight, kind, formula):
    got = parse_weight(title)
    assert (got["weight"], got["kind"], got["formula"]) == (weight, kind, formula)
    assert parse_units(title)[1] == weight


def it(n, title, price):
    return {"product_name": title, "price": price, "product_url": f"https://www.coupang.com/vp/products/{n}",
            "platform_name": "쿠팡", "is_coupang": True}


def test_option_list_titles_are_not_compared_by_weight():
    items = [it(1, "사과 경북 청송 가정용 부사 5kg 10kg", 25000), it(2, "부사 사과 5kg", 30000),
             it(3, "부사 사과 3kg", 21000)]
    res = search_products(SearchRequest(text="사과 추천"), shopping=FakeShopping(items=items))
    opt = next(i for i in res.items if i.product.title.endswith("5kg 10kg"))
    assert opt.product.weight_g is None and opt.offer.per100g_krw is None and opt.score.role != "value"
    ev = next(e for e in opt.evidence if e.field == "weight_g")
    assert ev.status == "conflict" and ev.raw_text == "5kg, 10kg" and "옵션 목록" in ev.source
    assert {d.use: d.verdict for d in ev.usage}["price_compare"] == "hold"
    value = next(i for i in res.items if i.score.role == "value")
    assert value.product.title == "부사 사과 5kg"                       # 100g당 600원 < 700원


def test_explicit_multiplication_uses_total_and_says_how():
    items = [it(1, "국산 삼겹살 500g x 2팩", 18000), it(2, "국산 삼겹살 1kg", 20000), it(3, "국산 삼겹살 300g", 7000)]
    res = search_products(SearchRequest(text="삼겹살 추천"), shopping=FakeShopping(items=items))
    two = next(i for i in res.items if i.product.title == "국산 삼겹살 500g x 2팩")
    assert two.product.weight_g == 1000 and two.offer.per100g_krw == 1800
    ev = next(e for e in two.evidence if e.field == "weight_g")
    assert ev.method == "title_parse" and ev.raw_text == "500g×2" and "계산" in ev.source
    assert two.score.role == "value"
    texts = [r.text for i in res.items for r in i.score.reasons]
    assert not any("500g×2" in t and "상품명 표기 기준" in t for t in texts)


def test_saved_cards_from_before_are_recomputed_with_the_new_rule():
    old = {"key": "a", "title": "사과 부사 5kg 10kg", "price": 25000, "total": 25000, "weight_g": 10000,
           "per100g": 250, "weight_source": "title"}
    # p31 에 '상품명 표기'로 저장된 카드도, 출처 기록이 없는 예전 카드도 지금 규칙으로 다시 계산
    for card in (old, {k: v for k, v in old.items() if k != "weight_source"}):
        fixed = explain.reweigh(card)
        assert fixed["weight_g"] is None and fixed["per100g"] is None and fixed["weight_source"] == "title_ambiguous"
    upstream = dict(old, weight_source="upstream")
    assert explain.reweigh(upstream) is upstream


def test_count_unclear_titles_keep_per_pack_price_but_no_weight_comparison():
    items = [it(1, "닭가슴살 100g 10팩", 15000), it(2, "닭가슴살 1kg", 16000), it(3, "닭가슴살 500g", 9000)]
    res = search_products(SearchRequest(text="닭가슴살 추천"), shopping=FakeShopping(items=items))
    packs = next(i for i in res.items if i.product.title == "닭가슴살 100g 10팩")
    assert packs.product.weight_g is None and packs.offer.per100g_krw is None
    assert packs.offer.per_unit_krw == 1500                       # 개당 가격은 그대로 (100g 해석과 무관)
    ev = next(e for e in packs.evidence if e.field == "weight_g")
    assert ev.status == "conflict" and ev.raw_text == "100g, 10팩" and "총중량 불명확" in ev.source
    assert packs.score.role not in ("value", "ample")
