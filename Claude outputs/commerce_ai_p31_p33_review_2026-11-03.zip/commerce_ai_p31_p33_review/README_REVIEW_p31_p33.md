# commerce_ai p31·p32·p33 검토 패키지 (2026-11-03) — 중량 출처·상품명 해석·잔여 값

코드는 맥 원본(`/Users/mom/commerce_ai_generator`) 현재 파일 사본. 커밋하지 않음. 비밀키·.env·data/ 미포함(검색 0건).

## 실행 환경 구분 (지적 반영)
| 로그 | 어디서 | 파이썬 |
|---|---|---|
| `test_logs/p3x_linux_copy_full.txt` | 맥 저장소를 Linux VM 으로 복사한 사본 (data/ 는 링크) | Linux Python 3.10 |
| `test_logs/p33_mac_folder_linux_python_weight_tests.txt` | 맥 원본 폴더 그대로 (VM 에 마운트) | Linux Python 3.10 |
| 맥 `.venv` (Python 3.14) | **아직 실행 안 함** | — |

전체(사본): p30 7 failed / 5,105 → p31 5,107 → p32 5,121 → p33 5,128 passed. 실패 7개 목록 동일. 증가분 = 새 테스트 수.

## p31 — 실제 출처 보존 · 미확인 DB 중량 제외
- `explain._amount` 가 (중량, 개입 수, **출처**) 를 돌려주고 `enrich` 가 카드에 `weight_source` 기록. 화면 응답(`_public`)에서 제외, 저장 후보(`saved.KEEP`)에 유지. `search._evidence` 는 숫자 비교가 아니라 이 기록을 씀.
- DB 대체 경로 `weight_g` 기본 미사용 (`CHAT_TRUST_UPSTREAM_WEIGHT` 기본 0).
- `selection_audit` 가 고른 상품뿐 아니라 함께 견준 후보(picks·others)까지 확인. 경고는 REST `_result_blocks` (첫 검색·예산 재선택) 에도.
- `compare/p31_db_weight_flag_on_vs_off.json`: 재현 데이터 전후 비교.

## p32 — 상품명 중량 해석
- 사용자 맥 `check_snapshot_weights.py` 결과: DB weight_g 240행 모두 naver_api, 상품명 중량과 같음 96 / 다름 144. 다른 행은 '5kg 10kg' 옵션 목록 상품명 — 수집기(`naver_shopping_api_collector.parse_weight_text`)는 첫 중량, 추천 코드는 마지막 중량을 읽어 어긋남.
- `explain.parse_weight`: single · multiplied('500g x 2' → 1000g, 계산식 기록) · ambiguous(서로 다른 중량 2개 이상 → 중량 없음).
- `compare/p32_before.json`(맥 p31 코드) vs `p32_after.json`(p32 코드): 같은 입력. 옵션 목록 상품이 10kg 으로 나뉘어 100g당 299원 '가성비' → 제외. '500g x 2팩' 3,600원 → 1,800원.

## p33 — GPT 검토(15:33) 세 항목
1. **'100g 10팩' 보류**: 곱하기 없이 개수(N>1)가 붙으면 `count_unclear` → 중량 없음(100g당 비교 제외). 개당 가격(per_unit)은 유지(중량 해석과 무관). 근거 status=conflict, raw_text '100g, 10팩'. '500g 1팩'은 그대로, '1kg (100g x 10팩)'은 곱한 값=총량이라 1000g.
2. **일괄 복구 방지**: `CHAT_TRUST_UPSTREAM_WEIGHT=1` 이어도 상위 항목에 `weight_verified is True`(행별 상품·옵션·가격 연결 확인 표시)가 있을 때만 DB 중량을 씀. 현재 그런 표시를 만드는 코드·데이터는 없음 → 사실상 계속 제외. 표시를 만드는 검증 절차는 미정.
3. **잔여 값 무효화**: 세 경로(첫 검색 · 예산 재선택 · 관심 상품 비교)에서 옵션 목록·개수 불명 상품의 weight_g·per100g 가 비고, 가성비·넉넉한 양 역할과 '100g당' 사유가 남지 않음을 REST 응답으로 확인. 예전 규칙으로 저장된 카드(마지막 중량·'가성비' 역할·'250원/100g' 사유)도 재선택 때 중량·100g당·역할·사유가 모두 새로 계산됨(`explain.reweigh` → `choose` 가 why·reason·role 재작성). 관심 상품 비교에도 중량 출처 경고 추가(p33 전에는 빠져 있었음).

## 남은 한계 (구현하지 않음)
- 곱하기 계산·상품명 중량은 **판매자 표기**이며, 표시 가격이 그 구성(옵션)에 적용된다는 연결은 확인하지 않는다 → 근거는 title_parse(price_compare=allow_labelled, '상품명 표기 기준' 표기), 점수(score)는 차단.
- 관리자 패키지(`app/admin/shared/markets/base.parse_units`)는 옛 규칙 그대로.
- `weight_verified` 를 부여할 행별 검증 절차·담당·기록 위치 미정.
- 맥 `.venv` 실행.
