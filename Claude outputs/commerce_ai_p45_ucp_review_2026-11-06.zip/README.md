# commerce_ai p45 — GPT 검토(2026-11-06 15:14) 반영 패키지

## 반영 내용
1. 검증기 필수: requirements.txt 에 jsonschema·referencing. schemas.prepare() 가 협상 catalog.search schema 와 모든 참조(49개)를
   판매자 요청 전에 확보 — 실패 시 판매자 POST 0회(REST·MCP). 검증은 확보분만으로(조회 없음). client.search 의 validate 옵션 제거,
   위반 시 response=None. 카드는 mapping.cards_from(outcome) — 검증 통과 결과로만.
2. 판매자 프로필 캐시: discovery.cache_seconds — 헤더 없음 0, max-age=N→N(최대 86400), no-store·no-cache·private→0(보관 안 함).
3. 판매자 단위가격 분리: seller_unit_price 표시만, UCP 카드 weight_g·per100g·per_unit=None + price_compare_blocked.
   explain.enrich·reweigh(_blocked) 재채움 차단, choose 의 weighed·counted 에서 제외.
4. C62 + increment>1: "N개 단위 주문 · 현재 카드에서 주문 조건 표시 불가" 보류, 가격은 1개 기준 그대로.

## 파일
- repo/: app/services/ucp/*, app/services/chat/explain.py(맥 최신본 + p45 3곳), check_ucp_catalog.py, check_ucp_profiles.py,
  make_ucp_profile.py, requirements.txt, tests/services/ucp(테스트 + 오프라인 ucp.dev 공식 schema 49개), data/ucp/merchants_template.csv
- before/: 변경 전 맥 원본 9개 · SHA256_before.txt
- p45.diff: 맥 원본 → 맥 반영본
- ucp_tests_p45.txt (99 passed) · subset_tests_p45.txt (ucp·chat·mcp·공개보호 645 passed / 1 failed = 기존 dev-trace)
- full_tests_after.txt: 맥 최신 기준 전체 7 failed / 5,411 passed (실패 7개는 p38 이후 같은 목록, UCP 무관)
- mutation_check_p45.txt: price_compare_blocked 보호를 끈 코드로 회귀 테스트 → 5 failed (테스트가 실제로 잡음)
- live_profile_check_p45.txt: https://trendguide.kr/.well-known/ucp 직접 200·application/json·public max-age=3600·리다이렉트 없음
- README.txt: 작업 중 사고와 복구 기록 (explain.py 를 오래된 사본으로 덮어썼다가 원본 복구 후 p45 3곳만 재적용)

## 검토 요청 지점
- prepare() 의 참조 수집(_refs: 외부 $ref 를 urljoin 후 fragment 제거)과 max_docs=80 제한
- cache_seconds 의 'public' 만 있고 max-age 없는 경우 0 처리
- 기존 카드 key 는 enrich 가 card_key(mall·pid·url·title)로 다시 만듦 — UCP 카드도 상품명 변경 시 key 변경 (회귀 테스트는 variant_id 로 식별)
- 남은 일: 공통 검색(collect) 연결 여부, 판매자 쪽(Business) 역할은 별도 설계

.env·키·개인정보 없음. 커밋하지 않음.
