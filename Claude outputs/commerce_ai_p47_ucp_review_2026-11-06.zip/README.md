# commerce_ai p47 — 스키마 포함 리소스 · 원화 UCP 공통 경로 연결 검증 (2026-11-06)

GPT 검토(11-06 17:25, p46 대상) 반영.  **앱 경로는 여전히 미연결** — `collect(extra_cards=...)` 는 검증용 입구이고 앱 코드는 넘기지 않는다(테스트로 고정).

## 1. 스키마: 문서 안 포함 리소스는 따로 가져오지 않음 (`app/services/ucp/schemas.py`)
- `embedded_ids()` — 받은 문서 안의 `$id`(중첩 포함, 기준 주소 반영) 주소 목록.  이 주소로 가는 참조는 외부 GET 하지 않는다.
- 수집 순서: 받은 문서를 모두 훑은 뒤 외부 후보를 하나씩 가져온다.  GET 실패는 끝까지 본 뒤 판정 — 뒤에 받은 문서에 포함된
  리소스였으면 실패가 아님.  같은 주소가 문서 안에도 있으면 문서 안의 것을 쓴다.
- `_subresources()` — 포함 리소스를 절대 주소로 registry 에 등록 (최상위 `$id` 가 없어도 받은 주소 기준으로).
- 실제 외부 참조가 없으면 그대로 `schema_unavailable`, 판매자 POST 0회.
- 테스트: GPT 재현(`$id: nested.json` + `$anchor: x` ← `nested.json#x`, 별도 주소 404, GET 은 루트 1회) ·
  뒤 문서에 포함된 리소스 · 최상위 `$id` 없는 문서 · 진짜 외부 누락은 보류(REST·MCP).

## 2. 원화 UCP 응답 → collect → enrich → choose → 공통 모델 (`tests/services/ucp/test_ucp_common_path.py`)
검증 통과한 실제 `client.search` 결과 → `cards_from` → `search_products(extra_cards=...)` 로 쿠팡 결과와 함께 처리.
연결해 보니 막혀 있지 않던 곳 3곳을 막았다:

| 발견 | 수정 |
|---|---|
| KAMIS 시세 비교가 상품명 수량('30구')으로 UCP 카드를 공공 시세와 견줄 수 있음 | `kamis.reference()` — `price_compare_blocked` 카드는 None |
| 상품명 개수('10입')가 `unit_count` 로 남아 공통 모델 근거에 '상품명 표기 기준 비교 허용'으로 나감 | `explain._blocked()` 가 `unit_count` 도 비움 |
| 공통 모델(`to_item`) 변환에서 `seller_unit_price`·판매자 고지·UCP 출처가 사라짐 | `_evidence()` 가 가격·판매자 단위가격·고지를 `method="ucp_catalog"` 근거로 보존 |

- 근거 용도 정책 `ucp_catalog`: 표시 allow_labelled('판매자 표시 (UCP 카탈로그)') · 거르기 hold · **가격 비교 block** · 점수 block.
  기존 판정은 그대로, `POLICY_VERSION` → `evidence-usage/2026-11-06`.
- 결과에 UCP 카드가 있으면 경고 한 줄: "UCP 판매처 가격은 카탈로그 값이에요 — 판매처 결제 화면 가격이 기준이고, 판매자 단위가격은 다른 판매처와 견주지 않았어요."
- 확인: key(변환 == 공통 모델) · `per100g/per_unit/weight_g/unit_count` 없음 · 판매자 단위가격 '100g당 630원 (판매자 표시)' 그대로 ·
  가성비·넉넉한 양은 쿠팡 카드끼리 · 판매자 단위가격·상품명 숫자를 바꿔도 역할·순서(key 기준) 동일 · 출처 실패 시 쿠팡 결과 그대로 ·
  `extra_cards` 없으면 결과 완전 동일 · 앱 코드는 `extra_cards=` 를 넘기지 않음.

## 검증
- `ucp_tests_p47.txt` UCP 139 passed (p46 122 → +17)
- `subset_tests_p47.txt` ucp·chat·public_price·mcp_adapter·public_guard 693 passed, 1 failed(기존 dev-trace, `.env` CHAT_DEV_TRACE=0)
- `full_tests_after.txt` 전체 5,450 passed, 8 failed — 기존 7개 + `test_f2a_has_no_external_python_imports` 1개.
  이 1개는 실행 사본에 `.git` 을 빼서 `git ls-files` 가 실패한 환경 문제 — 맥 원본에서 같은 테스트 1 passed.
- `mutation_check_p47.txt` 수정 하나씩 되돌리기: 스키마(3 실패) · KAMIS 차단(1) · 공통 모델 근거(3) · 가격 비교 허용으로 바꿈(2) ·
  unit_count 비우기는 처음엔 잡는 테스트가 없어 '10입' 사례를 추가(1).
- `live_search_p47.txt` allbirds 실제 검색: 협상·검색·응답 검증 통과(USD 5개 → 원화 카드 0개).

## 반영 전 확인
맥 대상 파일 mtime 이 p46 반영(08:14 UTC) 이전 그대로 — 다른 작업 변경 없음.  `p47.diff` 삭제 줄 18개는 모두 의도한 교체.

## 남은 결정 (연결 단계)
- UCP 카드는 배송비를 모름(total 없음) — 후보에 100g당 비교 가능한 카드가 2개 미만이면 '최저가'를 상품 가격으로 고르는 기존 규칙이
  UCP 카드에도 적용됨 (쿠팡 배송비 미상 카드와 같은 규칙).  배송비 미상 판매처를 최저가 후보로 둘지 연결 전에 정해야 함.
- 원화 판매 국내 UCP 판매자 확보.
